# CampusSync Assets Integration Pack

This package applies the instructions in `assets/README.md` to the CampusSync Next.js App Router project.

## Run it in Codespaces

Upload `campussync-assets-integration.zip` to the repository root (same level as `package.json`), then run:

```bash
cd /workspaces/campus-sync && unzip -oq campussync-assets-integration.zip -d /tmp/campussync-assets-bundle && python3 /tmp/campussync-assets-bundle/campussync-assets-integration/apply_campussync_assets.py /workspaces/campus-sync
```

Then verify:

```bash
cd /workspaces/campus-sync && npx tsc --noEmit && git diff --check && npm run build
```

Do not push until the build succeeds. The installer backs up files it overwrites under `/tmp/campussync-assets-backup-YYYYMMDD-HHMMSS`. It stages code edits and validates expected layout anchors before writing project source files. Optional JSX placements are skipped with a report if the current source pattern differs.

## Included

- Favicon, App Router icons, PWA manifest icons, and OGP image/metadata.
- Animated assets and empty-state illustrations under `public/animated/` and `public/illustrations/`.
- 5 score medals mapped to the documented 0-100 school-contribution score under `public/rank-badges/` and `lib/ranks.ts`.
- Cafeteria crowd and air-conditioning icons under `public/status-icons/` and `lib/status.ts`.
- A shared component for rank medals and status/empty-state imagery.
- README and OFL license notices.

The existing fifteen sword rank icons are preserved. Because the app's score is capped at 100, the installer also adjusts their thresholds to make all fifteen stages reachable across 0-100; the included five medals give users the broader tier (bronze/silver/gold/platinum/diamond).
