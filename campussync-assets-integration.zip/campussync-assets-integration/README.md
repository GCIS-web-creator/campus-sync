# CampusSync アセット適用パック

このパックは、同梱の `assets/README.md` にある指示に従い、Next.js App RouterのCampusSyncにアセットとコード連携を追加します。

## Codespacesでの適用

`campussync-assets-integration.zip` を `/workspaces/campus-sync` 直下（`package.json` と同じ階層）にアップロードしてから実行してください。

```bash
cd /workspaces/campus-sync && unzip -oq campussync-assets-integration.zip -d /tmp/campussync-assets-bundle && python3 /tmp/campussync-assets-bundle/campussync-assets-integration/apply_campussync_assets.py /workspaces/campus-sync
```

適用後に必ず確認:

```bash
cd /workspaces/campus-sync && npx tsc --noEmit && git diff --check && npm run build
```

ビルドが成功するまでGitHubにプッシュしないでください。上書きする既存ファイルは `/tmp/campussync-assets-backup-YYYYMMDD-HHMMSS/` にバックアップします。ソースの重要な構造が想定と異なる場合は、書き換えを止めます。

## 適用されるもの

- PWA・ファビコン・Appleホーム画面アイコン・OGP画像とNext.jsメタデータ
- 動くアイコン8点と空状態イラスト8点
- 学食の混雑/エアコンの状態アイコンと `lib/status.ts`
- 0〜100点に対応する5段階メダル、`lib/ranks.ts` と貢献度カード上の表示
- 既存の15種類の剣ランクは保持し、現在のスコアが0〜100点のため、15段階すべてに到達できる境界へ調整
- READMEとOFLライセンス通知

動くアイコンや空状態イラストは、検出できた対応箇所にのみ自動配置します。それ以外も `public/animated/` と `public/illustrations/` にコピーされ、後から追加利用できます。
