// app/layout.tsx に追記する例(Next.js App Router)
// 前提: favicon-and-app/ のファイルを public/ に、og-image.png を public/ にコピー済み
import type { Metadata, Viewport } from 'next';

export const metadata: Metadata = {
  title: 'CampusSync',
  description: '学校生活をひとつにつなぐ',
  manifest: '/site.webmanifest',
  icons: {
    icon: [
      { url: '/favicon.ico', sizes: 'any' },
      { url: '/favicon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-touch-icon.png',
  },
  openGraph: {
    title: 'CampusSync',
    description: '学校生活をひとつにつなぐ',
    locale: 'ja_JP',
    type: 'website',
    images: [{ url: '/og-image.png', width: 1200, height: 630, alt: 'CampusSync' }],
  },
  twitter: { card: 'summary_large_image', images: ['/og-image.png'] },
};

export const viewport: Viewport = { themeColor: '#2B4FD8' };
