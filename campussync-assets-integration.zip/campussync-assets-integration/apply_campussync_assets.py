#!/usr/bin/env python3
"""Apply the CampusSync asset pack according to its bundled README.

The installer stages all text edits before writing any project files, creates backups
under /tmp, and treats optional UI placements as non-fatal when a known pattern is absent.
"""
from __future__ import annotations

import re
import shutil
import sys
import time
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
ASSET_ROOT = PACKAGE_DIR / "assets"

class StopApply(Exception):
    pass


def brace_end(text: str, opening: int) -> int:
    """Find matching } while ignoring ordinary JS strings and comments."""
    depth = 0
    quote = None
    escape = False
    line_comment = False
    block_comment = False
    i = opening
    while i < len(text):
        c = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if line_comment:
            if c == "\n":
                line_comment = False
            i += 1
            continue
        if block_comment:
            if c == "*" and nxt == "/":
                block_comment = False
                i += 2
            else:
                i += 1
            continue
        if quote:
            if escape:
                escape = False
            elif c == "\\":
                escape = True
            elif c == quote:
                quote = None
            i += 1
            continue
        if c == "/" and nxt == "/":
            line_comment = True
            i += 2
            continue
        if c == "/" and nxt == "*":
            block_comment = True
            i += 2
            continue
        if c in "'\"`":
            quote = c
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    raise StopApply("layout.tsxのオブジェクトを解析できませんでした。")


def top_level_properties(obj_text: str) -> dict[str, tuple[int, int]]:
    """Return property value spans relative to a JS object literal string."""
    open_idx = obj_text.find("{")
    if open_idx < 0:
        raise StopApply("metadataオブジェクトが見つかりません。")
    close_idx = brace_end(obj_text, open_idx)
    props: dict[str, tuple[int, int]] = {}
    i = open_idx + 1
    while i < close_idx:
        while i < close_idx and (obj_text[i].isspace() or obj_text[i] == ","):
            i += 1
        if i >= close_idx:
            break
        if obj_text.startswith("//", i):
            nl = obj_text.find("\n", i + 2)
            i = close_idx if nl < 0 else nl + 1
            continue
        if obj_text.startswith("/*", i):
            end_comment = obj_text.find("*/", i + 2)
            i = close_idx if end_comment < 0 else end_comment + 2
            continue
        key_match = re.match(r"([A-Za-z_$][\w$]*)\s*:", obj_text[i:])
        if not key_match:
            # Unknown/spread syntax: skip to the next top-level comma without editing it.
            val_start = i
        else:
            key = key_match.group(1)
            colon_idx = i + key_match.end() - 1
            val_start = colon_idx + 1
            while val_start < close_idx and obj_text[val_start].isspace():
                val_start += 1
            j = val_start
            curly = square = paren = 0
            q = None
            esc = False
            line = block = False
            while j < close_idx:
                ch = obj_text[j]
                nx = obj_text[j + 1] if j + 1 < close_idx else ""
                if line:
                    if ch == "\n": line = False
                    j += 1; continue
                if block:
                    if ch == "*" and nx == "/": block = False; j += 2
                    else: j += 1
                    continue
                if q:
                    if esc: esc = False
                    elif ch == "\\": esc = True
                    elif ch == q: q = None
                    j += 1; continue
                if ch == "/" and nx == "/": line = True; j += 2; continue
                if ch == "/" and nx == "*": block = True; j += 2; continue
                if ch in "'\"`": q = ch
                elif ch == "{": curly += 1
                elif ch == "}":
                    if curly == 0 and square == 0 and paren == 0: break
                    curly -= 1
                elif ch == "[": square += 1
                elif ch == "]": square -= 1
                elif ch == "(": paren += 1
                elif ch == ")": paren -= 1
                elif ch == "," and curly == 0 and square == 0 and paren == 0: break
                j += 1
            val_end = j
            while val_end > val_start and obj_text[val_end - 1].isspace():
                val_end -= 1
            props[key] = (val_start, val_end)
            i = j + 1 if j < close_idx and obj_text[j] == "," else j
            continue
        # Skip unrecognized property/spread safely.
        j = val_start
        curly = square = paren = 0
        q = None
        esc = False
        while j < close_idx:
            ch = obj_text[j]
            if q:
                if esc: esc = False
                elif ch == "\\": esc = True
                elif ch == q: q = None
            elif ch in "'\"`": q = ch
            elif ch == "{": curly += 1
            elif ch == "}":
                if curly == 0 and square == 0 and paren == 0: break
                curly -= 1
            elif ch == "[": square += 1
            elif ch == "]": square -= 1
            elif ch == "(": paren += 1
            elif ch == ")": paren -= 1
            elif ch == "," and curly == 0 and square == 0 and paren == 0: break
            j += 1
        i = j + 1 if j < close_idx and obj_text[j] == "," else j
    return props


def upsert_object(obj_text: str, required: dict[str, str]) -> str:
    props = top_level_properties(obj_text)
    replacements = [(span[0], span[1], val) for key, val in required.items() if (span := props.get(key))]
    result = obj_text
    for start, end, val in sorted(replacements, reverse=True):
        result = result[:start] + val + result[end:]
    props_after = top_level_properties(result)
    missing = [(key, value) for key, value in required.items() if key not in props_after]
    if missing:
        open_idx = result.find("{")
        close_idx = brace_end(result, open_idx)
        before = result[:close_idx].rstrip()
        comma = "" if before.endswith(",") or before.endswith("{") else ","
        addition = comma + "\n" + "\n".join(f"  {key}: {value}," for key, value in missing) + "\n"
        result = result[:close_idx] + addition + result[close_idx:]
    return result


def ensure_next_types(text: str) -> str:
    pattern = re.compile(r"import\s+type\s*\{([^}]+)\}\s*from\s*(['\"])next\2\s*;?")
    m = pattern.search(text)
    if m:
        names = [n.strip() for n in m.group(1).split(",") if n.strip()]
        for required in ("Metadata", "Viewport"):
            if required not in names:
                names.append(required)
        replacement = "import type { " + ", ".join(names) + " } from 'next';"
        return text[:m.start()] + replacement + text[m.end():]
    # Add the import after a possible directive, before the first source statement.
    directive = re.match(r"\s*(['\"])use client\1\s*;?\s*", text)
    pos = directive.end() if directive else 0
    return text[:pos] + "\nimport type { Metadata, Viewport } from 'next';\n" + text[pos:]


def update_layout(layout: str) -> str:
    is_client = bool(re.match(r"\s*(['\"])use client\1", layout))
    layout = re.sub(r'<html\b([^>]*?)\blang\s*=\s*([\"\'])[^\"\']*\2', r'<html\1lang="ja"', layout, count=1)
    metadata_values = {
        "title": "'CampusSync'",
        "description": "'学校生活をひとつにつなぐ'",
        "manifest": "'/site.webmanifest'",
        "icons": "{ icon: [{ url: '/favicon.ico', sizes: 'any' }, { url: '/favicon.svg', type: 'image/svg+xml' }], apple: '/apple-touch-icon.png' }",
        "openGraph": "{ title: 'CampusSync', description: '学校生活をひとつにつなぐ', locale: 'ja_JP', type: 'website', images: [{ url: '/og-image.png', width: 1200, height: 630, alt: 'CampusSync' }] }",
        "twitter": "{ card: 'summary_large_image', images: ['/og-image.png'] }",
    }
    if is_client:
        # Client layout cannot export metadata; use an explicit head like README advises.
        head_markup = '''<head>
        <meta name="description" content="学校生活をひとつにつなぐ" />
        <meta name="theme-color" content="#2B4FD8" />
        <link rel="manifest" href="/site.webmanifest" />
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <meta property="og:title" content="CampusSync" />
        <meta property="og:description" content="学校生活をひとつにつなぐ" />
        <meta property="og:locale" content="ja_JP" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:image" content="/og-image.png" />
      </head>'''
        if re.search(r"<head\b[^>]*>[\s\S]*?</head>", layout):
            layout = re.sub(r"<head\b[^>]*>[\s\S]*?</head>", head_markup, layout, count=1)
        else:
            layout, n = re.subn(r"(<html\b[^>]*>)", r"\1\n      " + head_markup, layout, count=1)
            if not n:
                print("注意：layout.tsxがClient Componentで、HTMLの<head>を特定できませんでした。OGP/manifestリンクは手動確認が必要です。")
        return layout

    # Server Component: use Metadata API. Update an existing metadata object or add one.
    declaration = re.search(r"export\s+const\s+metadata(?:\s*:\s*[^=]+)?\s*=\s*\{", layout)
    if declaration:
        open_idx = declaration.end() - 1
        close_idx = brace_end(layout, open_idx)
        obj = layout[open_idx:close_idx + 1]
        new_obj = upsert_object(obj, metadata_values)
        layout = layout[:open_idx] + new_obj + layout[close_idx + 1:]
    else:
        layout = ensure_next_types(layout)
        new_metadata = """export const metadata: Metadata = {
  title: 'CampusSync',
  description: '学校生活をひとつにつなぐ',
  manifest: '/site.webmanifest',
  icons: { icon: [{ url: '/favicon.ico', sizes: 'any' }, { url: '/favicon.svg', type: 'image/svg+xml' }], apple: '/apple-touch-icon.png' },
  openGraph: { title: 'CampusSync', description: '学校生活をひとつにつなぐ', locale: 'ja_JP', type: 'website', images: [{ url: '/og-image.png', width: 1200, height: 630, alt: 'CampusSync' }] },
  twitter: { card: 'summary_large_image', images: ['/og-image.png'] },
};

"""
        default_match = re.search(r"export\s+default\s+(?:async\s+)?function\b", layout)
        if default_match:
            layout = layout[:default_match.start()] + new_metadata + layout[default_match.start():]
        else:
            raise StopApply("app/layout.tsxに既存metadataもdefault functionも見つかりません。")

    viewport_values = {"themeColor": "'#2B4FD8'"}
    view_decl = re.search(r"export\s+const\s+viewport(?:\s*:\s*[^=]+)?\s*=\s*\{", layout)
    if view_decl:
        o = view_decl.end() - 1
        c = brace_end(layout, o)
        obj = layout[o:c + 1]
        layout = layout[:o] + upsert_object(obj, viewport_values) + layout[c + 1:]
    else:
        # The Metadata interface is exported by Next; keep viewport options isolated.
        vp = "export const viewport: Viewport = { themeColor: '#2B4FD8' };\n\n"
        default_match = re.search(r"export\s+default\s+(?:async\s+)?function\b", layout)
        if default_match:
            layout = layout[:default_match.start()] + vp + layout[default_match.start():]
    layout = ensure_next_types(layout)
    return layout


def main() -> int:
    if len(sys.argv) > 1:
        root = Path(sys.argv[1]).resolve()
    else:
        root = Path.cwd().resolve()
    if not (root / "app/page.tsx").is_file() or not (root / "app/layout.tsx").is_file():
        print(f"中止：Next.jsプロジェクトの app/page.tsx と app/layout.tsx が必要です: {root}")
        return 1

    required_assets = [ASSET_ROOT / "README.md", ASSET_ROOT / "animated", ASSET_ROOT / "illustrations", ASSET_ROOT / "rank-badges", ASSET_ROOT / "status-icons", ASSET_ROOT / "favicon-and-app", ASSET_ROOT / "ogp"]
    missing_assets = [str(p) for p in required_assets if not p.exists()]
    if missing_assets:
        print("中止：パックに必要なアセットがありません:\n" + "\n".join(missing_assets))
        return 1

    try:
        page_path = root / "app/page.tsx"
        layout_path = root / "app/layout.tsx"
        page = page_path.read_text(encoding="utf-8")
        layout = layout_path.read_text(encoding="utf-8")
        staged: dict[Path, str] = {page_path: page, layout_path: update_layout(layout)}
        messages: list[str] = []

        # Add shared asset widgets import idempotently.
        widget_import = "import { ScoreRankBadge, EmptyStateIllustration, CrowdStatusIcon, AirconColdIcon, AirconComfortableIcon, AirconHotIcon } from '@/components/CampusAssetWidgets';"
        if "@/components/CampusAssetWidgets" not in page:
            # insert after the first import line when possible; directive remains first.
            lines = page.splitlines(keepends=True)
            last_import = -1
            for i, line in enumerate(lines):
                if line.startswith("import ") or (last_import >= 0 and line.strip() and not line.startswith("import ") and i < last_import + 8):
                    if line.startswith("import "):
                        last_import = i
                if last_import >= 0 and i > last_import + 15:
                    break
            insert_after = last_import
            if insert_after >= 0:
                lines.insert(insert_after + 1, widget_import + "\n")
                page = "".join(lines)
            else:
                page = page.replace("'use client';", "'use client';\n\n" + widget_import, 1)
            messages.append("app/page.tsx: アセット表示コンポーネントのimportを追加")

        def replace_once(src: str, old: str, new: str, label: str, required: bool = False) -> str:
            if new in src:
                messages.append(label + "（適用済み）")
                return src
            count = src.count(old)
            if count == 1:
                messages.append(label)
                return src.replace(old, new, 1)
            if required:
                raise StopApply(f"{label}: 対象が{count}か所です（想定1か所）。ページを変更せず中止しました。")
            messages.append(label + f"（パターンなしのためスキップ: {count}）")
            return src

        # Score medal follows the README's documented 0–100 point scale.
        score_pattern = re.compile(r'(<h2 className="text-xs font-semibold text-white/80 mb-0\.5">本日のリアルタイム学校貢献度</h2>\s*<p className="text-4xl font-black tracking-tight">\{score\} <span className="text-base font-medium text-white/70">/ 100 pt</span></p>)')
        if "<ScoreRankBadge points={Number(score ?? 0)} />" not in page:
            page, n = score_pattern.subn(r'\1\n                <ScoreRankBadge points={Number(score ?? 0)} />', page, count=1)
            messages.append("貢献度カードに5段階メダルを追加" if n else "貢献度カードのテキストが異なるため、メダル表示の自動配置をスキップ")

        # Animated use cases from README: loading, QR scanning and unread notification indicator.
        spinner = '<div className="mx-auto h-10 w-10 rounded-full border-4 border-cyan-300/30 border-t-cyan-300 animate-spin" />'
        page = replace_once(page, spinner, '<img src="/animated/loading-logo.svg" alt="" className="mx-auto h-20 w-16 max-w-full object-contain" />', "読み込み表示をロゴアニメーションに変更")
        qr = '{!cardScanDone && <div id="campus-sync-qr-reader" className="w-full overflow-hidden rounded-2xl" />}'
        page = replace_once(page, qr, '{!cardScanDone && <div className="space-y-2"><img src="/animated/qr-scan.svg" alt="" className="mx-auto h-12 w-12 object-contain" /><div id="campus-sync-qr-reader" className="w-full min-w-0 overflow-hidden rounded-2xl" /></div>}', "QR読取アニメーションを追加")
        page = replace_once(page, '<SidebarItem icon={<Bell size={18} />} label="通知・連絡"', '<SidebarItem icon={<img src="/animated/bell-ring.svg" alt="" className="h-[18px] w-[18px] shrink-0 object-contain" />} label="通知・連絡"', "未読通知のベルアニメーションを追加")

        # Status icons: crowd vote rows and HVAC state cards.
        crowd_line = '{label} {isVoted && <Check size={12} className="text-blue-500 font-black"/>}'
        page = replace_once(page, crowd_line, '<CrowdStatusIcon value={type} label={label} />{label} {isVoted && <Check size={12} className="text-blue-500 font-black"/>}', "学食混雑VoteBarに状態アイコンを追加")
        page = replace_once(page, 'let icon = ThermometerSnowflake;', 'let icon: React.ElementType = AirconComfortableIcon;', "エアコン快適アイコンを状態判定に設定")
        cold_count = page.count('icon = Wind;')
        if cold_count:
            page = page.replace('icon = Wind;', 'icon = AirconColdIcon;')
            messages.append(f"エアコン寒い状態のアイコンを変更（{cold_count}か所）")
        hot_count = page.count('icon = ThermometerSun;')
        if hot_count:
            page = page.replace('icon = ThermometerSun;', 'icon = AirconHotIcon;')
            messages.append(f"エアコン暑い状態のアイコンを変更（{hot_count}か所）")
        comfy_count = page.count('icon = ThermometerSnowflake;')
        if comfy_count:
            page = page.replace('icon = ThermometerSnowflake;', 'icon = AirconComfortableIcon;')
            messages.append(f"エアコン快適状態のアイコンを変更（{comfy_count}か所）")

        # Add contextual illustrations to common empty-list states where the JSX mapping exists.
        empty_specs = [
            ("visibleTodos", "empty-todo-done", "課題はすべて完了！おつかれさま"),
            ("lostAndFoundList", "empty-lost-found", "共有された落とし物はまだありません。"),
            ("cafeteriaReviews", "empty-reviews", "まだ口コミがありません。"),
            ("filteredReviews", "empty-reviews", "まだ口コミがありません。"),
            ("clubNotes", "empty-club-note", "部活・委員会の連絡はまだありません。"),
            ("visibleNotifications", "empty-notifications", "新しい通知はありません。"),
            ("notifications", "empty-notifications", "新しい通知はありません。"),
            ("filteredLibraryBooks", "empty-library-search", "タイトルまたは著者名を変えて検索してください。"),
            ("filteredBooks", "empty-library-search", "タイトルまたは著者名を変えて検索してください。"),
        ]
        for var, kind, caption in empty_specs:
            marker = f'<EmptyStateIllustration kind="{kind}"'
            if marker in page:
                continue
            pat = re.compile(r'\{\s*' + re.escape(var) + r'\.map\s*\(')
            repl = '{' + var + f'.length === 0 && <EmptyStateIllustration kind="{kind}" caption="{caption}" />}}\n          {{' + var + '.map('
            page, n = pat.subn(repl, page, count=1)
            if n:
                messages.append(f"空状態イラストを配置: {var} → {kind}")

        # Avoid clipping on flexible containers and ensure img SVGs do not shrink inside navs.
        page = replace_once(page, 'className="flex flex-col items-center justify-center w-14 pt-1 gap-0.5 flex-shrink-0"', 'className="flex flex-col items-center justify-center w-14 pt-1 gap-0.5 flex-shrink-0 [&_svg]:block [&_svg]:shrink-0 [&_img]:block [&_img]:shrink-0"', "スマホナビのSVG/アニメ画像サイズを安定化")

        # Adjust all fifteen sword thresholds because the app score is capped at 100.
        rank_path = root / "components/ContributionRanks.tsx"
        rank_content = rank_path.read_text(encoding="utf-8") if rank_path.exists() else None
        if rank_content:
            old_thresholds = [
                "minPoints: 0", "minPoints: 100", "minPoints: 250", "minPoints: 500", "minPoints: 1000",
                "minPoints: 1500", "minPoints: 2000", "minPoints: 2500", "minPoints: 3000", "minPoints: 3500",
                "minPoints: 4000", "minPoints: 4500", "minPoints: 5000", "minPoints: 6000", "minPoints: 8000",
            ]
            new_thresholds = [f"minPoints: {v}" for v in [0, 7, 14, 21, 28, 35, 42, 49, 56, 63, 70, 77, 84, 91, 98]]
            def threshold_count(text: str, value: int) -> int:
                return len(re.findall(r'minPoints\s*:\s*' + re.escape(str(value)) + r'(?!\d)', text))
            counts = [threshold_count(rank_content, int(old.split(':', 1)[1])) for old in old_thresholds]
            new_values = [int(value.split(':', 1)[1]) for value in new_thresholds]
            if all(c == 1 for c in counts):
                for old_value, new_value in reversed(list(zip([int(x.split(':', 1)[1]) for x in old_thresholds], new_values))):
                    rank_pattern = re.compile(r'(minPoints\s*:\s*)' + re.escape(str(old_value)) + r'(?!\d)')
                    rank_content, changed = rank_pattern.subn(lambda m: m.group(1) + str(new_value), rank_content, count=1)
                    if changed != 1:
                        raise StopApply(f"剣ランク境界 {old_value} の置換に失敗しました。")
                staged[rank_path] = rank_content
                messages.append("15種類の剣ランクを現在の0〜100点スコアで到達可能な段階に調整")
            elif all(threshold_count(rank_content, value) == 1 for value in new_values):
                messages.append("15種類の剣ランクの基準は適用済み")
            else:
                messages.append("剣ランクの境界値が異なるため自動変更をスキップ（手動確認推奨）")
        else:
            messages.append("components/ContributionRanks.tsxが見つからず剣ランク境界は変更しません")

        # Replace existing contribution guide fixed overlay with normal in-flow panel and move it out of table rows if detected.
        if rank_content and 'fixed bottom-4 right-4 z-[60] w-[min(26rem,calc(100vw-2rem))]' in rank_content:
            rank_content = rank_content.replace('fixed bottom-4 right-4 z-[60] w-[min(26rem,calc(100vw-2rem))]', 'w-full min-w-0 max-w-3xl', 1)
            staged[rank_path] = rank_content

        # Include all files from the README's intended deployment locations.
        copies: dict[Path, Path] = {}
        for dirname in ("animated", "illustrations", "rank-badges", "status-icons"):
            for src in (ASSET_ROOT / dirname).rglob("*"):
                if src.is_file():
                    rel = src.relative_to(ASSET_ROOT / dirname)
                    copies[root / "public" / dirname / rel] = src
        fa = ASSET_ROOT / "favicon-and-app"
        for src_name, dest in [
            ("favicon.ico", "app/favicon.ico"),
            ("icon-512.png", "app/icon.png"),
            ("apple-touch-icon.png", "app/apple-icon.png"),
            ("favicon.svg", "public/favicon.svg"),
            ("favicon-16.png", "public/favicon-16.png"),
            ("favicon-32.png", "public/favicon-32.png"),
            ("favicon-48.png", "public/favicon-48.png"),
            ("apple-touch-icon.png", "public/apple-touch-icon.png"),
            ("site.webmanifest", "public/site.webmanifest"),
            ("icon-any.svg", "public/icons/icon-any.svg"),
            ("icon-maskable.svg", "public/icons/icon-maskable.svg"),
            ("icon-192.png", "public/icons/icon-192.png"),
            ("icon-512.png", "public/icons/icon-512.png"),
            ("icon-maskable-192.png", "public/icons/icon-maskable-192.png"),
            ("icon-maskable-512.png", "public/icons/icon-maskable-512.png"),
        ]:
            copies[root / dest] = fa / src_name
        ogp = ASSET_ROOT / "ogp"
        copies[root / "public/og-image.png"] = ogp / "og-image.png"
        copies[root / "public/og-image.svg"] = ogp / "og-image.svg"
        for source_name, dest_name in [("tools/OFL-Noto.txt", "OFL-Noto.txt"), ("tools/OFL-Poppins.txt", "OFL-Poppins.txt")]:
            src = ASSET_ROOT / source_name
            if src.exists():
                copies[root / "public/branding/licenses" / dest_name] = src

        # Helper modules following the README contracts.
        ranks_src = ASSET_ROOT / "rank-badges/ranks.ts"
        status_src = ASSET_ROOT / "status-icons/status.ts"
        ranks_dest = root / "lib/ranks.ts"
        status_dest = root / "lib/status.ts"
        if ranks_src.exists():
            copies[ranks_dest] = ranks_src
        if status_src.exists():
            copies[status_dest] = status_src

        widget = root / "components/CampusAssetWidgets.tsx"
        widget_content = r'''import React from 'react';
import { getRank, getNextRank } from '@/lib/ranks';
import { CROWD_ICONS } from '@/lib/status';

export type IllustrationKind =
  | 'empty-notifications' | 'empty-todo-done' | 'empty-reviews' | 'empty-lost-found'
  | 'empty-library-search' | 'empty-club-note' | 'error-offline' | 'empty-no-class';

const ILLUSTRATIONS: Record<IllustrationKind, string> = {
  'empty-notifications': '/illustrations/empty-notifications.svg',
  'empty-todo-done': '/illustrations/empty-todo-done.svg',
  'empty-reviews': '/illustrations/empty-reviews.svg',
  'empty-lost-found': '/illustrations/empty-lost-found.svg',
  'empty-library-search': '/illustrations/empty-library-search.svg',
  'empty-club-note': '/illustrations/empty-club-note.svg',
  'error-offline': '/illustrations/error-offline.svg',
  'empty-no-class': '/illustrations/empty-no-class.svg',
};

export function EmptyStateIllustration({ kind, caption, className = '' }: {
  kind: IllustrationKind; caption: string; className?: string;
}) {
  return (
    <div className={`mx-auto flex w-full min-w-0 flex-col items-center justify-center px-3 py-5 text-center ${className}`}>
      <img src={ILLUSTRATIONS[kind]} alt="" loading="lazy" className="h-auto w-40 max-w-full object-contain sm:w-48" />
      <p className="mt-2 max-w-prose text-sm font-semibold leading-relaxed text-slate-500 dark:text-slate-400">{caption}</p>
    </div>
  );
}

export function AnimatedAsset({ name, alt = '', className = '' }: {
  name: 'loading-logo' | 'qr-scan' | 'bell-ring' | 'aircon-wind' | 'cafeteria-steam' | 'lost-found-search' | 'train-move' | 'trophy-shine';
  alt?: string;
  className?: string;
}) {
  return <img src={`/animated/${name}.svg`} alt={alt} aria-hidden={alt ? undefined : true} className={`max-w-full object-contain ${className}`} />;
}

export function ScoreRankBadge({ points }: { points: number }) {
  const rank = getRank(points);
  const next = getNextRank(points);
  return (
    <div className="mt-2 inline-flex min-w-0 max-w-full items-center gap-2 rounded-xl border border-white/20 bg-white/10 p-2 text-white">
      <img src={rank.src} alt={`${rank.label}メダル`} width={48} height={54} className="h-[54px] w-12 shrink-0 object-contain" />
      <div className="min-w-0">
        <p className="text-sm font-black">{rank.label}ランク</p>
        <p className="text-xs leading-relaxed text-white/80">{next ? `あと${next.remaining} ptで${next.rank.label}` : '最高ランク到達！'}</p>
      </div>
    </div>
  );
}

export function CrowdStatusIcon({ value, label }: { value: string; label: string }) {
  const search = `${value} ${label}`.toLowerCase();
  const key = /empty|空いて|空き|すいて/.test(search) ? 'empty'
    : /crowd|混雑|混ん/.test(search) ? 'crowded'
    : /normal|通常|普通/.test(search) ? 'normal' : null;
  if (!key) return null;
  const item = CROWD_ICONS[key];
  return <img src={item.src} alt="" aria-hidden="true" title={item.label} className="inline-block h-5 w-5 shrink-0 object-contain" />;
}

type StatusIconProps = { size?: number; className?: string };
function StatusImage({ src, size = 24, className = '' }: StatusIconProps & { src: string }) {
  return <img src={src} alt="" aria-hidden="true" width={size} height={size} className={`inline-block shrink-0 object-contain ${className}`} style={{ width: size, height: size }} />;
}
export function AirconColdIcon(props: StatusIconProps) { return <StatusImage src="/status-icons/ac-cold.svg" {...props} />; }
export function AirconComfortableIcon(props: StatusIconProps) { return <StatusImage src="/status-icons/ac-comfy.svg" {...props} />; }
export function AirconHotIcon(props: StatusIconProps) { return <StatusImage src="/status-icons/ac-hot.svg" {...props} />; }
'''
        staged[widget] = widget_content
        staged[page_path] = page

        # Empty-state assets use only JSX map expressions that are demonstrably present.
        # For lists not found, assets are still installed and available through CampusAssetWidgets.

    except Exception as exc:
        print(f"中止：{exc}")
        print("対象ファイルは書き換えていません。")
        return 1

    # Copy and write only after all source transformations are staged successfully.
    backup_root = Path("/tmp") / f"campussync-assets-backup-{time.strftime('%Y%m%d-%H%M%S')}"
    targets = set(staged) | set(copies)
    for target in targets:
        if target.exists() and target.is_file():
            rel = target.relative_to(root) if target.is_relative_to(root) else Path("package") / target.name
            backup = backup_root / rel
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, backup)
    for target, content in staged.items():
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    for target, src in copies.items():
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target)

    # Copy the README to the repository docs folder for reference.
    readme_dest = root / "docs/CampusSync-assets-README.md"
    readme_dest.parent.mkdir(parents=True, exist_ok=True)
    readme_src = ASSET_ROOT / "README.md"
    if readme_dest.exists():
        backup = backup_root / "docs/CampusSync-assets-README.md"
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(readme_dest, backup)
    shutil.copy2(readme_src, readme_dest)

    print("CampusSyncアセットを適用しました。")
    print("\n変更内容:")
    for msg in messages:
        print(f" - {msg}")
    print(f"\n配置ファイル: {len(copies)}個（既存ファイルは上書き前にバックアップ）")
    print(f"バックアップ: {backup_root}")
    print("次に `npx tsc --noEmit && git diff --check && npm run build` を実行してください。")
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
