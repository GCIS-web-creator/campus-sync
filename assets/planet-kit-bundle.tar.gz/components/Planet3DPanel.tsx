'use client';

import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';
import { Orbit, RotateCw, Sparkles } from 'lucide-react';

const PlanetCanvas = dynamic(
  () => import('@/lib/planet-kit/react/PlanetCanvas').then((module) => module.PlanetCanvas),
  {
    ssr: false,
    loading: () => (
      <div className="flex h-[360px] items-center justify-center text-xs font-semibold text-cyan-100/70">
        3D惑星を準備しています…
      </div>
    ),
  },
);

const PLANETS = [
  { id: 'planet-001', name: 'アスタリア', type: '地球型' },
  { id: 'planet-002', name: 'オケアナ', type: '海洋' },
  { id: 'planet-003', name: 'カルサ', type: '砂漠' },
  { id: 'planet-004', name: 'グラシエル', type: '氷結' },
  { id: 'planet-005', name: 'エンベリア', type: '火山' },
  { id: 'planet-006', name: 'ヴェルディア', type: '森林' },
  { id: 'planet-007', name: 'アウレオン', type: '環を持つ巨大惑星' },
  { id: 'planet-008', name: 'セルリア', type: '氷の巨大惑星' },
  { id: 'planet-009', name: 'ルミナ・クリスタ', type: '結晶' },
  { id: 'planet-010', name: 'ペトラ', type: '岩石' },
] as const;

const STORAGE_KEY = 'campussync:planet-view:selected-planet:v1';

export default function Planet3DPanel({ stage }: { stage: number }) {
  const [planetId, setPlanetId] = useState<string>('planet-001');
  const [viewError, setViewError] = useState('');
  const selected = PLANETS.find((planet) => planet.id === planetId) ?? PLANETS[0];

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY);
      if (saved && PLANETS.some((planet) => planet.id === saved)) setPlanetId(saved);
    } catch {
      // Storage may be unavailable in private browsing; the in-memory selection still works.
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, planetId);
    } catch {
      // The selected planet remains available for the current session.
    }
  }, [planetId]);

  return (
    <section className="min-w-0 overflow-hidden rounded-[26px] border border-cyan-200/15 bg-[#06152b] shadow-[0_25px_70px_rgba(2,12,27,.28)]">
      <div className="relative overflow-hidden bg-[radial-gradient(ellipse_at_50%_45%,rgba(31,116,156,.3),transparent_58%),linear-gradient(145deg,#081b35,#040b1c)]">
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-3 p-4 sm:p-5">
          <div>
            <p className="text-[9px] font-black tracking-[.22em] text-cyan-200/80">PLANETARY OBSERVATORY</p>
            <h2 className="mt-1 text-lg font-black text-white sm:text-xl">{selected.name}</h2>
            <p className="mt-1 text-[10px] text-cyan-100/65">{selected.type} · Civilization Stage {stage}</p>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-cyan-100/20 bg-slate-950/40 px-3 py-1.5 text-[9px] font-bold text-cyan-100 backdrop-blur">
            <Sparkles size={12}/> 360° 3D
          </span>
        </div>

        <div className="relative h-[360px] w-full sm:h-[440px]">
          <PlanetCanvas
            planetId={planetId}
            catalogBase="/planet-assets"
            quality="auto"
            timeScale={1}
            sun={{ mode: 'fixed', azimuthDeg: -62, elevationDeg: 8 }}
            layers={{ clouds: true, atmosphere: true, ring: true, emissive: true, relief: true, objects: false }}
            cameraDistance={1.12}
            className="h-full w-full"
            style={{ height: '100%', width: '100%' }}
            onError={(error) => setViewError(error.message)}
          />
          {viewError && (
            <div role="alert" className="absolute inset-x-4 bottom-4 rounded-xl border border-rose-300/30 bg-slate-950/90 px-3 py-2 text-[10px] leading-5 text-rose-100 backdrop-blur">
              3D表示を開始できませんでした。WebGL対応ブラウザで再読み込みしてください。<span className="block opacity-70">{viewError}</span>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/10 bg-[#0a1b33]/90 px-4 py-3 sm:px-5">
          <div className="flex items-center gap-2 text-[10px] text-cyan-100/75">
            <RotateCw size={14}/><span>ドラッグで回転 · ホイール／ピンチで拡大縮小</span>
          </div>
          <div className="inline-flex items-center gap-1 text-[9px] font-bold text-cyan-100/55"><Orbit size={12}/>自転アニメーション</div>
        </div>
      </div>

      <div className="border-t border-cyan-100/10 bg-[#07162a] p-3 sm:p-4">
        <div className="mb-2 flex items-center justify-between gap-2">
          <p className="text-[10px] font-black text-cyan-100/80">惑星を選択</p>
          <p className="text-[9px] text-slate-400">選択はこの端末に保存されます</p>
        </div>
        <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-5">
          {PLANETS.map((planet) => {
            const active = planet.id === planetId;
            return (
              <button
                key={planet.id}
                type="button"
                aria-pressed={active}
                onClick={() => { setViewError(''); setPlanetId(planet.id); }}
                className={`min-w-0 rounded-xl border px-2 py-2 text-left transition ${active ? 'border-cyan-300/55 bg-cyan-300/15 text-white shadow-[inset_0_0_0_1px_rgba(103,232,249,.12)]' : 'border-white/10 bg-white/[.035] text-slate-300 hover:border-cyan-200/30 hover:bg-white/[.07]'}`}
              >
                <span className="block truncate text-[10px] font-black">{planet.name}</span>
                <span className={`mt-0.5 block truncate text-[8px] ${active ? 'text-cyan-100/80' : 'text-slate-500'}`}>{planet.type}</span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
