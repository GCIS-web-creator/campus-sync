import * as THREE from 'three';
import type { MotionSpec } from '../core/types';
import type { SystemModel } from '../core/system';

/**
 * 開発・検証用の簡易天体(恒星、仮の衛星球)。製品素材ではない。
 *  - 恒星: フェーズ7で本格的な恒星・コロナ素材に置き換える
 *  - 仮衛星: 衛星の入れ子公転(親の位置+軌道)が機能することを検証するためだけに使う
 */
export function makeDevStar(radius: number): THREE.Group {
  const g = new THREE.Group();
  g.add(new THREE.Mesh(new THREE.SphereGeometry(radius, 48, 32), new THREE.MeshBasicMaterial({ color: 0xfff1c9 })));
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const ctx = c.getContext('2d')!;
  const gr = ctx.createRadialGradient(64, 64, 6, 64, 64, 64);
  gr.addColorStop(0, 'rgba(255,230,170,0.95)'); gr.addColorStop(0.3, 'rgba(255,190,110,0.35)'); gr.addColorStop(1, 'rgba(255,150,60,0)');
  ctx.fillStyle = gr; ctx.fillRect(0, 0, 128, 128);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
  sp.scale.setScalar(radius * 6);
  g.add(sp);
  return g;
}
export function makeDevMoon(id: string, parentId: string, system: SystemModel, motion: MotionSpec, radius: number, color = 0x9aa4b2) {
  system.add({ id, parentId, radius, motion });
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(radius, 32, 20), new THREE.MeshLambertMaterial({ color }));
  return {
    mesh,
    update: (t: number) => { const p = system.position(id, t); mesh.position.set(p[0], p[1], p[2]); },
    dispose: () => { mesh.geometry.dispose(); (mesh.material as THREE.Material).dispose(); mesh.removeFromParent(); system.remove(id); },
  };
}
