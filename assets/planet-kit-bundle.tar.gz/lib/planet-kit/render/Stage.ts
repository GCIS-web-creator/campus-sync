import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { SimClock } from '../core/time';
import { SystemModel } from '../core/system';
import { orbitPath } from '../core/orbit';
import { detectCaps, type DeviceCaps } from '../assets/quality';
import { TextureCache } from '../assets/textureCache';
import { PlanetView } from './PlanetView';

export interface StageOptions {
  canvas: HTMLCanvasElement;
  clock?: SimClock;
  /** prefers-reduced-motion のとき自動で一時停止して開始する(既定 true) */
  respectReducedMotion?: boolean;
}
export type SunMode = { mode: 'fixed'; azimuthDeg: number; elevationDeg: number } | { mode: 'orbit' };

/**
 * 描画ステージ: レンダラ・カメラ・操作・星空・時計・ループ。
 * 画面外(タブ非表示/キャンバスが画面外)では描画を止め、復帰時は絶対時刻から位置を再計算する。
 */
export class Stage {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(40, 1, 0.05, 4000);
  readonly controls: OrbitControls;
  readonly clock: SimClock;
  readonly caps: DeviceCaps;
  readonly textures: TextureCache;
  readonly views = new Map<string, PlanetView>();
  readonly system: SystemModel;
  sun: SunMode = { mode: 'fixed', azimuthDeg: -62, elevationDeg: 8 };
  onFrame?: (dtMs: number) => void;
  readonly sunLight = new THREE.DirectionalLight(0xffffff, 2.4);
  private focusId: string | null = null;
  private raf = 0;
  private running = false;
  private onScreen = true;
  private stars: THREE.Points;
  private extras = new Map<string, { update: (t: number) => void; dispose: () => void }>();
  private io?: IntersectionObserver;
  private ro: ResizeObserver;
  private lastFrame = 0;
  frames = 0;
  fps = 0;
  private fpsAcc = 0; private fpsN = 0;

  constructor(private o: StageOptions, epochMs: number) {
    this.renderer = new THREE.WebGLRenderer({ canvas: o.canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.caps = detectCaps({ maxTextureSize: this.renderer.capabilities.maxTextureSize });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, this.caps.maxPixelRatio));
    this.renderer.setClearColor(0x03050b, 1);
    this.textures = new TextureCache(Math.min(8, this.renderer.capabilities.getMaxAnisotropy()));
    this.system = new SystemModel(epochMs);
    const reduce = (o.respectReducedMotion ?? true) && typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;
    this.clock = o.clock ?? new SimClock({ paused: reduce });
    this.camera.position.set(0, 0.6, 5);
    this.controls = new OrbitControls(this.camera, o.canvas);
    Object.assign(this.controls, { enableDamping: true, dampingFactor: 0.08, rotateSpeed: 0.7, zoomSpeed: 0.8, panSpeed: 0.7, screenSpacePanning: true });
    this.stars = makeStars();
    this.scene.add(this.stars);
    // 検証用の簡易天体(仮の衛星など Lambert 材質)のための光源。惑星・建物は独自シェーダで太陽方向を受け取る。
    this.scene.add(this.sunLight, new THREE.AmbientLight(0x8899bb, 0.35));
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(o.canvas);
    if (typeof IntersectionObserver !== 'undefined') {
      this.io = new IntersectionObserver((es) => { this.onScreen = es[es.length - 1].isIntersecting; }, { threshold: 0 });
      this.io.observe(o.canvas);
    }
    document.addEventListener('visibilitychange', this.onVis);
    this.resize();
  }
  private onVis = () => { this.lastFrame = 0; };

  resize() {
    const c = this.o.canvas;
    const w = c.clientWidth || 800, h = c.clientHeight || 600;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }
  addPlanet(view: PlanetView) {
    this.views.set(view.def.id, view);
    this.scene.add(view.root);
    const m = view.def.motion;
    this.system.add({ id: view.def.id, radius: view.radius, motion: m });
  }
  removePlanet(id: string) {
    const v = this.views.get(id); if (!v) return;
    v.dispose(); this.views.delete(id); this.system.remove(id);
    if (this.focusId === id) this.focusId = null;
  }
  addExtra(id: string, e: { update: (t: number) => void; dispose: () => void }) { this.extras.get(id)?.dispose(); this.extras.set(id, e); }
  removeExtra(id: string) { this.extras.get(id)?.dispose(); this.extras.delete(id); }

  /**
   * カメラを天体に追従させる。scale=1 は「惑星(リング含む)が画面の縦横どちらにも収まる最小距離」。
   * 縦長のスマートフォン画面でも横幅に収まるよう、縦横の画角の狭い方で距離を決める。
   */
  focus(id: string, scale = 1.25) {
    const v = this.views.get(id); if (!v) throw new Error(`unknown view: ${id}`);
    this.focusId = id;
    this.syncPositions(this.clock.now());
    const c = v.root.position.clone();
    const fitR = v.radius * (v.def.layers.ring ? v.def.layers.ring.outerRadius : 1.08);
    const vHalf = (this.camera.fov * Math.PI) / 360;
    const hHalf = Math.atan(Math.tan(vHalf) * this.camera.aspect);
    const dist = ((fitR * 1.12) / Math.sin(Math.min(vHalf, hHalf))) * scale;
    const dir = this.camera.position.clone().sub(this.controls.target);
    if (dir.lengthSq() < 1e-6) dir.set(0, 0.15, 1);
    dir.normalize().multiplyScalar(dist);
    this.controls.target.copy(c);
    this.camera.position.copy(c).add(dir);
    this.controls.minDistance = v.radius * 1.25;
    this.controls.maxDistance = 600;
  }
  private syncPositions(t: number) {
    for (const [id, v] of this.views) {
      const p = this.system.position(id, t);
      v.root.position.set(p[0], p[1], p[2]);
    }
  }
  private updateSun(v: PlanetView) {
    const d = new THREE.Vector3();
    if (this.sun.mode === 'orbit') d.copy(v.root.position).negate();
    else {
      const az = (this.sun.azimuthDeg * Math.PI) / 180, el = (this.sun.elevationDeg * Math.PI) / 180;
      // カメラ基準: azimuth=0 でカメラ正面方向から照らす
      const fwd = this.camera.position.clone().sub(this.controls.target).setY(0);
      if (fwd.lengthSq() < 1e-6) fwd.set(0, 0, 1);
      fwd.normalize();
      const base = Math.atan2(fwd.x, fwd.z);
      d.set(Math.sin(base + az) * Math.cos(el), Math.sin(el), Math.cos(base + az) * Math.cos(el));
    }
    v.setSunDirection(d);
    this.sunLight.position.copy(d).multiplyScalar(100).add(v.root.position);
    this.sunLight.target.position.copy(v.root.position);
    this.sunLight.target.updateMatrixWorld();
  }
  orbitLine(id: string, color = 0x4a6a9a): THREE.Line | null {
    const n = this.system.get(id);
    if (!n.motion.orbit) return null;
    const pts = orbitPath(n.motion.orbit).map((p) => new THREE.Vector3(...p));
    return new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.5 }));
  }

  start() { if (this.running) return; this.running = true; const loop = (now: number) => { if (!this.running) return; this.raf = requestAnimationFrame(loop); this.frame(now); }; this.raf = requestAnimationFrame(loop); }
  stop() { this.running = false; cancelAnimationFrame(this.raf); }

  frame(now: number) {
    const dt = this.lastFrame ? now - this.lastFrame : 16; this.lastFrame = now;
    this.fpsAcc += dt; this.fpsN++;
    if (this.fpsAcc > 500) { this.fps = Math.round((this.fpsN * 1000) / this.fpsAcc); this.fpsAcc = 0; this.fpsN = 0; }
    if (!this.onScreen) return; // 画面外では描画・更新を抑制
    const t = this.clock.now();
    this.syncPositions(t);
    if (this.focusId) {
      const v = this.views.get(this.focusId)!;
      const delta = v.root.position.clone().sub(this.controls.target);
      this.camera.position.add(delta);
      this.controls.target.add(delta);
    }
    this.controls.update();
    const hPx = this.renderer.domElement.height;
    for (const v of this.views.values()) { this.updateSun(v); v.update(t, this.camera, hPx, now); }
    this.extras.forEach((e) => e.update(t));
    this.stars.position.copy(this.camera.position);
    this.onFrame?.(dt);
    this.renderer.render(this.scene, this.camera);
    this.frames++;
  }
  dispose() {
    this.stop(); this.ro.disconnect(); this.io?.disconnect();
    document.removeEventListener('visibilitychange', this.onVis);
    this.views.forEach((v) => v.dispose()); this.views.clear();
    this.extras.forEach((e) => e.dispose()); this.extras.clear();
    this.controls.dispose(); this.textures.disposeAll();
    this.stars.geometry.dispose(); (this.stars.material as THREE.Material).dispose();
    this.renderer.dispose();
  }
}

function makeStars(): THREE.Points {
  const n = 2200, pos = new Float32Array(n * 3), col = new Float32Array(n * 3);
  let s = 12345; const r = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  for (let i = 0; i < n; i++) {
    const z = r() * 2 - 1, a = r() * Math.PI * 2, q = Math.sqrt(1 - z * z), R = 1800;
    pos.set([q * Math.cos(a) * R, z * R, q * Math.sin(a) * R], i * 3);
    const b = 0.35 + r() * 0.65, warm = r();
    col.set([b * (0.8 + 0.2 * warm), b * 0.9, b * (1 - 0.25 * warm)], i * 3);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const p = new THREE.Points(g, new THREE.PointsMaterial({ size: 1.6, sizeAttenuation: false, vertexColors: true, transparent: true, opacity: 0.9, depthWrite: false }));
  p.frustumCulled = false;
  return p;
}
