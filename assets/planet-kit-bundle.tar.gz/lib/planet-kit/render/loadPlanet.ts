import type { AssetCatalog } from '../assets/catalog';
import type { QualityTier } from '../assets/quality';
import { PlanetView } from './PlanetView';
import type { Stage } from './Stage';

/** IDを指定するだけで惑星を生成・読み込み・ステージへ追加する。 */
export async function loadPlanet(stage: Stage, catalog: AssetCatalog, id: string, quality: QualityTier | 'auto' = 'auto'): Promise<PlanetView> {
  const def = catalog.getPlanet(id);
  const view = new PlanetView({ def, epochMs: catalog.epochMs, textures: stage.textures, url: (r) => catalog.url(id, r), caps: stage.caps, quality });
  stage.addPlanet(view);
  await view.load();
  return view;
}
