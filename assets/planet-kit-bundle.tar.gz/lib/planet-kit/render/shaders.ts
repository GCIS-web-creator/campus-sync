/** GLSL。three.js の ShaderMaterial(WebGL2)用。色空間変換は colorspace_fragment に任せる。 */

export const planetVert = /* glsl */ `
varying vec2 vUv; varying vec3 vN; varying vec3 vE; varying vec3 vNo; varying vec3 vWorldPos;
void main() {
  vUv = uv;
  mat3 m = mat3(modelMatrix);
  vec3 n = normalize(m * normal);
  vec3 eastObj = normalize(cross(vec3(0.0, 1.0, 0.0), normal + vec3(1e-5, 0.0, 0.0)));
  vE = normalize(m * eastObj);
  vN = n;
  vNo = normalize(cross(n, vE));
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorldPos = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;

export const planetFrag = /* glsl */ `
uniform sampler2D uMap; uniform sampler2D uEmissive;
uniform float uHasEmissive; uniform float uEmissiveIntensity; uniform float uEmissiveDay;
uniform vec3 uSun; uniform float uRelief; uniform vec2 uTexel;
uniform vec3 uAtmoColor; uniform float uAtmoStrength; uniform float uNight;
varying vec2 vUv; varying vec3 vN; varying vec3 vE; varying vec3 vNo; varying vec3 vWorldPos;
float lum(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
  vec3 albedo = texture2D(uMap, vUv).rgb;
  vec3 n = normalize(vN);
  // 輝度勾配による擬似起伏(クレーター縁・山脈・亀裂に陰影が出る)
  float hE = lum(texture2D(uMap, vUv + vec2(uTexel.x, 0.0)).rgb);
  float hW = lum(texture2D(uMap, vUv - vec2(uTexel.x, 0.0)).rgb);
  float hN = lum(texture2D(uMap, vUv + vec2(0.0, uTexel.y)).rgb);
  float hS = lum(texture2D(uMap, vUv - vec2(0.0, uTexel.y)).rgb);
  float cosLat = max(cos((vUv.y - 0.5) * 3.14159265), 0.3);
  vec2 g = vec2((hE - hW) / cosLat, (hN - hS)) / (2.0 * uTexel.x * 6.2831853) * uRelief * 0.012;
  float gl = length(g); if (gl > 1.1) g *= 1.1 / gl;
  vec3 nb = normalize(n - g.x * vE - g.y * vNo);
  float ndlS = dot(n, uSun);
  float ndl = dot(nb, uSun);
  float dayMask = smoothstep(-0.08, 0.14, ndlS);
  float light = max(ndl, 0.0) * dayMask;
  vec3 color = albedo * (uNight + 1.12 * light);
  // 大気: 縁の空気遠近 + 夕暮れの色づき
  vec3 v = normalize(cameraPosition - vWorldPos);
  float ndv = max(dot(n, v), 0.0);
  float rim = pow(1.0 - ndv, 3.0);
  float twilight = exp(-pow((ndlS - 0.04) / 0.16, 2.0));
  color = mix(color, uAtmoColor * (0.25 + 0.75 * dayMask), clamp(rim * 0.5 * uAtmoStrength * (0.25 + 0.75 * dayMask), 0.0, 0.85));
  color += uAtmoColor * twilight * 0.12 * uAtmoStrength;
  if (uHasEmissive > 0.5) {
    vec3 em = texture2D(uEmissive, vUv).rgb * uEmissiveIntensity;
    color += em * ((1.0 - dayMask) + uEmissiveDay);
  }
  gl_FragColor = vec4(color, 1.0);
  #include <colorspace_fragment>
}`;

export const cloudFrag = /* glsl */ `
uniform sampler2D uMap; uniform vec3 uSun; uniform float uOpacity; uniform float uNight; uniform vec3 uTint;
varying vec2 vUv; varying vec3 vN; varying vec3 vE; varying vec3 vNo; varying vec3 vWorldPos;
void main() {
  vec4 t = texture2D(uMap, vUv);
  vec3 n = normalize(vN);
  float ndl = dot(n, uSun);
  float dayMask = smoothstep(-0.1, 0.18, ndl);
  float light = uNight + (1.05 - uNight) * max(ndl, 0.0) * dayMask;
  float tw = exp(-pow((ndl - 0.03) / 0.12, 2.0)) * 0.25;
  vec3 c = t.rgb * uTint * light + vec3(1.0, 0.55, 0.3) * tw * t.a;
  gl_FragColor = vec4(c, t.a * uOpacity);
  #include <colorspace_fragment>
}`;

export const atmoVert = /* glsl */ `
varying vec3 vN; varying vec3 vWorldPos; varying vec3 vWorldN;
void main() {
  vN = normalize(normalMatrix * normal);
  vWorldN = normalize(mat3(modelMatrix) * normal);
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorldPos = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;

/** 球殻の内側(前面): フレネルで縁を発光させる。昼側ほど強く、夜側は薄明だけ残る */
export const atmoInnerFrag = /* glsl */ `
uniform vec3 uColor; uniform vec3 uSun; uniform float uIntensity; uniform float uPower;
varying vec3 vN; varying vec3 vWorldPos; varying vec3 vWorldN;
void main() {
  vec3 v = normalize(cameraPosition - vWorldPos);
  float f = pow(1.0 - max(dot(normalize(vWorldN), v), 0.0), uPower);
  float sunF = smoothstep(-0.35, 0.55, dot(normalize(vWorldN), uSun));
  float a = clamp(f * sunF * uIntensity, 0.0, 1.0);
  gl_FragColor = vec4(uColor, a);
  #include <colorspace_fragment>
}`;

/** 球殻の外側(背面): 惑星の外へにじむハロ */
export const atmoHaloFrag = /* glsl */ `
uniform vec3 uColor; uniform vec3 uSun; uniform vec3 uCenter; uniform float uIntensity; uniform float uMaxDot; uniform float uPower;
varying vec3 vN; varying vec3 vWorldPos; varying vec3 vWorldN;
void main() {
  vec3 v = normalize(cameraPosition - vWorldPos);
  float d = -dot(normalize(vWorldN), v);
  float t = clamp(d / uMaxDot, 0.0, 1.0);
  float f = pow(t, uPower);
  vec3 dir = normalize(vWorldPos - uCenter);
  float sunF = smoothstep(-0.45, 0.5, dot(dir, uSun));
  float a = clamp(f * sunF * uIntensity, 0.0, 1.0);
  gl_FragColor = vec4(uColor, a);
  #include <colorspace_fragment>
}`;

export const ringVert = /* glsl */ `
varying vec2 vUv; varying vec3 vWorldPos;
void main() {
  vUv = uv;
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorldPos = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;

/** リング: 惑星の影(円柱影)を落とし、太陽とリング面の角度で明るさが変わる */
export const ringFrag = /* glsl */ `
uniform sampler2D uMap; uniform vec3 uSun; uniform vec3 uCenter; uniform float uR; uniform float uOpacity;
uniform float uAngle; uniform vec3 uRingNormal; uniform vec3 uLit;
varying vec2 vUv; varying vec3 vWorldPos;
void main() {
  vec4 t = texture2D(uMap, vec2(vUv.x, fract(vUv.y + uAngle)));
  vec3 p = vWorldPos - uCenter;
  float along = dot(p, uSun);
  float d = length(p - uSun * along);
  float shadow = along < 0.0 ? 1.0 - smoothstep(uR * 0.985, uR * 1.025, d) : 0.0;
  float inc = abs(dot(uRingNormal, uSun));
  float lit = 0.55 + 0.45 * inc;
  vec3 c = t.rgb * uLit * lit * (0.06 + 0.94 * (1.0 - shadow));
  gl_FragColor = vec4(c, t.a * uOpacity);
  #include <colorspace_fragment>
}`;

/** 地表オブジェクト(建物など)。惑星と同じ太陽方向で陰影、夜側では窓の光が点る。 */
export const objVert = /* glsl */ `
varying vec3 vN; varying vec3 vBase; varying vec3 vLocal;
void main() {
  vN = normalize(mat3(modelMatrix) * normal);
  vLocal = position;
  vBase = (modelMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
  gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);
}`;
export const objFrag = /* glsl */ `
uniform vec3 uColor; uniform vec3 uGlow; uniform vec3 uSun; uniform vec3 uCenter; uniform float uGhost; uniform float uSelected; uniform float uWinH;
varying vec3 vN; varying vec3 vBase; varying vec3 vLocal;
void main() {
  vec3 n = normalize(vN);
  float planetDay = smoothstep(-0.12, 0.2, dot(normalize(vBase - uCenter), uSun));
  float ndl = max(dot(n, uSun), 0.0);
  vec3 c = uColor * (0.2 + 0.95 * ndl * planetDay);
  float win = 0.55 + 0.45 * step(0.5, fract(vLocal.y * uWinH));
  c += uGlow * (1.0 - planetDay) * win;
  c = mix(c, vec3(0.45, 0.8, 1.0), uSelected * 0.35);
  float a = mix(1.0, 0.28, uGhost);
  if (uGhost > 0.5) c = mix(c, vec3(0.35, 0.55, 0.8), 0.6);
  gl_FragColor = vec4(c, a);
  #include <colorspace_fragment>
}`;
