import * as THREE from 'three';
import type { PlanetDef } from '../core/types';
import { cyclicAngle, DEG, rotationAngle } from '../core/time';
import { vecToLatLon } from '../core/geo';
import { TIER_WIDTH, nextTier, tierForScreenRadius, type DeviceCaps, type QualityTier } from '../assets/quality';
import { TextureCache } from '../assets/textureCache';
import { atmoHaloFrag, atmoInnerFrag, atmoVert, cloudFrag, planetFrag, planetVert, ringFrag, ringVert } from './shaders';
import { SurfaceObjectManager } from './surfaceObjects';

export type LayerName = 'clouds' | 'atmosphere' | 'ring' | 'emissive' | 'objects' | 'relief';
export type PickResult = { kind: 'object'; id: string; point: THREE.Vector3 } | { kind: 'surface'; lat: number; lon: number; point: THREE.Vector3 };

export interface PlanetViewOptions {
  def: PlanetDef;
  epochMs: number;
  textures: TextureCache;
  /** ロールに応じた素材URLを返す(AssetCatalog.url を渡す) */
  url: (role: 'surface' | 'clouds' | 'emissive' | 'ring' | 'thumbnail') => string;
  caps: DeviceCaps;
  /** 'auto' は画面上の大きさで切替。固定tierも可 */
  quality?: QualityTier | 'auto';
}

const geoCache = new Map<string, THREE.SphereGeometry>();
function sphereGeo(seg: [number, number]) {
  const k = seg.join('x');
  let g = geoCache.get(k);
  if (!g) { g = new THREE.SphereGeometry(1, seg[0], seg[1]); geoCache.set(k, g); }
  return g;
}
const placeholder = (() => { const t = new THREE.DataTexture(new Uint8Array([40, 50, 70, 255]), 1, 1); t.needsUpdate = true; return t; })();

/**
 * 1つの惑星の描画単位。構造:
 *   root(公転位置)
 *    ├ tilt(自転軸の傾き)
 *    │   ├ spin(自転)  ← 表面マップ・地表オブジェクト(建物等)がここに載る=自転に完全追従
 *    │   ├ clouds(独立回転) / ring(独立回転)
 *    ├ atmosphere / halo(球対称)
 *    └ far sprite(遠景用の軽量表示)
 */
export class PlanetView {
  readonly root = new THREE.Group();
  readonly tilt = new THREE.Group();
  readonly spin = new THREE.Group();
  readonly objects: SurfaceObjectManager;
  readonly def: PlanetDef;
  readonly radius: number;
  tier: QualityTier;
  private auto: boolean;
  private surface: THREE.Mesh;
  private clouds?: THREE.Mesh;
  private ring?: THREE.Mesh;
  private atmo?: THREE.Mesh;
  private halo?: THREE.Mesh;
  private far?: THREE.Sprite;
  private shared = { sun: new THREE.Vector3(1, 0.2, 0.4).normalize(), center: new THREE.Vector3() };
  private held = new Map<string, { key: string }>();
  private pendingTier: QualityTier | null = null;
  private disposed = false;
  private layerState: Record<LayerName, boolean> = { clouds: true, atmosphere: true, ring: true, emissive: true, objects: true, relief: true };
  private farMode = false;
  private lastRadiusPx = 0;
  private downgradeSince = 0;

  constructor(private o: PlanetViewOptions) {
    this.def = o.def;
    this.radius = o.def.radius;
    this.auto = (o.quality ?? 'auto') === 'auto';
    this.tier = o.quality && o.quality !== 'auto' ? o.quality : o.caps.maxTier === 'low' ? 'low' : 'medium';
    const R = this.radius, L = o.def.layers, m = o.def.motion;
    const seg = o.caps.sphereSegments;
    this.root.name = o.def.id;
    this.root.add(this.tilt);
    this.tilt.rotation.order = 'YXZ';
    this.tilt.rotation.y = m.tiltAzimuthDeg * DEG;
    this.tilt.rotation.z = m.axialTiltDeg * DEG;
    this.tilt.add(this.spin);

    const atmoCol = new THREE.Color(L.atmosphere?.color ?? '#000000');
    this.surface = new THREE.Mesh(sphereGeo(seg), new THREE.ShaderMaterial({
      vertexShader: planetVert, fragmentShader: planetFrag,
      uniforms: {
        uMap: { value: placeholder }, uEmissive: { value: placeholder }, uHasEmissive: { value: 0 },
        uEmissiveIntensity: { value: L.emissive?.intensity ?? 0 }, uEmissiveDay: { value: L.emissive?.dayFactor ?? 0 },
        uSun: { value: this.shared.sun }, uRelief: { value: L.relief.strength }, uTexel: { value: new THREE.Vector2(1 / 2048, 1 / 1024) },
        uAtmoColor: { value: atmoCol }, uAtmoStrength: { value: L.atmosphere ? L.atmosphere.intensity : 0 }, uNight: { value: 0.035 },
      },
    }));
    this.surface.scale.setScalar(R);
    this.surface.renderOrder = 0;
    this.spin.add(this.surface);
    this.objects = new SurfaceObjectManager(this.spin, R, this.shared, (url) => o.textures.acquire(url, 'low', { aspect: 1, wrapS: THREE.ClampToEdgeWrapping }));

    if (L.clouds) {
      this.clouds = new THREE.Mesh(sphereGeo(seg), new THREE.ShaderMaterial({
        vertexShader: planetVert, fragmentShader: cloudFrag, transparent: true, depthWrite: false,
        uniforms: { uMap: { value: placeholder }, uSun: { value: this.shared.sun }, uOpacity: { value: L.clouds.opacity }, uNight: { value: 0.03 }, uTint: { value: new THREE.Color('#ffffff') } },
      }));
      this.clouds.scale.setScalar(R * (1 + L.clouds.altitude));
      this.clouds.renderOrder = 1;
      this.tilt.add(this.clouds);
    }
    if (L.ring) {
      const r = L.ring;
      this.ring = new THREE.Mesh(ringGeometry(r.innerRadius * R, r.outerRadius * R), new THREE.ShaderMaterial({
        vertexShader: ringVert, fragmentShader: ringFrag, transparent: true, depthWrite: false, side: THREE.DoubleSide,
        uniforms: {
          uMap: { value: placeholder }, uSun: { value: this.shared.sun }, uCenter: { value: this.shared.center }, uR: { value: R },
          uOpacity: { value: r.opacity }, uAngle: { value: 0 }, uRingNormal: { value: new THREE.Vector3(0, 1, 0) }, uLit: { value: new THREE.Color(r.litColor) },
        },
      }));
      this.ring.rotation.x = r.tiltDeg * DEG;
      this.ring.renderOrder = 2;
      this.tilt.add(this.ring);
    }
    if (L.atmosphere) {
      const a = L.atmosphere;
      const inner = 1 + a.thickness * 0.7, haloS = 1 + a.thickness * 2.4;
      this.atmo = new THREE.Mesh(sphereGeo(seg), new THREE.ShaderMaterial({
        vertexShader: atmoVert, fragmentShader: atmoInnerFrag, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
        uniforms: { uColor: { value: atmoCol }, uSun: { value: this.shared.sun }, uIntensity: { value: 1.25 * a.intensity }, uPower: { value: a.falloff } },
      }));
      this.atmo.scale.setScalar(R * inner);
      this.atmo.renderOrder = 3;
      this.halo = new THREE.Mesh(sphereGeo([48, 32]), new THREE.ShaderMaterial({
        vertexShader: atmoVert, fragmentShader: atmoHaloFrag, transparent: true, depthWrite: false, side: THREE.BackSide, blending: THREE.AdditiveBlending,
        uniforms: { uColor: { value: atmoCol }, uSun: { value: this.shared.sun }, uCenter: { value: this.shared.center }, uIntensity: { value: 0.85 * a.halo }, uMaxDot: { value: Math.sqrt(1 - 1 / (haloS * haloS)) }, uPower: { value: 2.6 } },
      }));
      this.halo.scale.setScalar(R * haloS);
      this.halo.renderOrder = 4;
      this.root.add(this.atmo, this.halo);
    }
  }

  /** 現在のtierで必要なテクスチャを読み込む(失敗時は例外)。 */
  async load(): Promise<void> { await this.applyTier(this.tier); }

  private async applyTier(tier: QualityTier) {
    const { textures: tc, url } = this.o;
    const keys = new Map<string, { key: string }>();
    const grab = async (role: 'surface' | 'clouds' | 'emissive' | 'ring', opts: { aspect: number; wrapT?: THREE.Wrapping }) => {
      const p = tc.acquire(url(role), tier, opts);
      keys.set(role, { key: p.key });
      return p;
    };
    const jobs: Promise<void>[] = [];
    const sm = this.surface.material as THREE.ShaderMaterial;
    jobs.push(grab('surface', { aspect: 0.5 }).then((t) => { sm.uniforms.uMap.value = t; sm.uniforms.uTexel.value.set(1 / t.image.width, 1 / t.image.height); }));
    if (this.def.files.emissive) jobs.push(grab('emissive', { aspect: 0.5 }).then((t) => { sm.uniforms.uEmissive.value = t; sm.uniforms.uHasEmissive.value = this.layerState.emissive ? 1 : 0; }));
    if (this.clouds && this.def.files.clouds) jobs.push(grab('clouds', { aspect: 0.5 }).then((t) => { (this.clouds!.material as THREE.ShaderMaterial).uniforms.uMap.value = t; }));
    if (this.ring && this.def.files.ring) jobs.push(grab('ring', { aspect: 0.25 }).then((t) => { t.wrapT = THREE.RepeatWrapping; t.needsUpdate = true; (this.ring!.material as THREE.ShaderMaterial).uniforms.uMap.value = t; }));
    try { await Promise.all(jobs); } catch (e) { keys.forEach((k) => tc.release(k.key)); throw e; }
    if (this.disposed) { keys.forEach((k) => tc.release(k.key)); return; }
    this.held.forEach((k) => tc.release(k.key));
    this.held = keys;
    this.tier = tier;
  }

  setQuality(q: QualityTier | 'auto') {
    this.auto = q === 'auto';
    if (q !== 'auto' && q !== this.tier) void this.applyTier(q);
  }
  get textureWidth() { return TIER_WIDTH[this.tier]; }

  setSunDirection(dir: THREE.Vector3) { this.shared.sun.copy(dir).normalize(); }
  get sunDirection() { return this.shared.sun; }
  setLayerVisible(l: LayerName, v: boolean) {
    this.layerState[l] = v;
    switch (l) {
      case 'clouds': if (this.clouds) this.clouds.visible = v; break;
      case 'atmosphere': if (this.atmo) this.atmo.visible = v; if (this.halo) this.halo.visible = v; (this.surface.material as THREE.ShaderMaterial).uniforms.uAtmoStrength.value = v && this.def.layers.atmosphere ? this.def.layers.atmosphere.intensity : 0; break;
      case 'ring': if (this.ring) this.ring.visible = v; break;
      case 'emissive': (this.surface.material as THREE.ShaderMaterial).uniforms.uHasEmissive.value = v && this.def.files.emissive && this.held.has('emissive') ? 1 : 0; break;
      case 'objects': this.spin.children.forEach((c) => { if (c !== this.surface) c.visible = v; }); break;
      case 'relief': (this.surface.material as THREE.ShaderMaterial).uniforms.uRelief.value = v ? this.def.layers.relief.strength : 0; break;
    }
  }
  isLayerVisible(l: LayerName) { return this.layerState[l]; }

  /**
   * 毎フレーム呼ぶ。位置(root.position)は呼び出し側(軌道計算)が設定済みであること。
   * 角度はすべて絶対時刻 tMs から直接計算する(積算しない)ので、停止・復帰後も正しい。
   */
  update(tMs: number, camera: THREE.PerspectiveCamera, viewportHeightPx: number, nowMs = performance.now()) {
    const m = this.def.motion, L = this.def.layers;
    this.root.getWorldPosition(this.shared.center);
    this.spin.rotation.y = rotationAngle(m, this.o.epochMs, tMs);
    if (this.clouds && L.clouds) this.clouds.rotation.y = cyclicAngle(0, L.clouds.rotationPeriodSec, this.o.epochMs, tMs);
    if (this.ring && L.ring) {
      const mat = this.ring.material as THREE.ShaderMaterial;
      mat.uniforms.uAngle.value = cyclicAngle(0, L.ring.rotationPeriodSec, this.o.epochMs, tMs) / (Math.PI * 2);
      mat.uniforms.uRingNormal.value.set(0, 1, 0).applyQuaternion(this.ring.getWorldQuaternion(new THREE.Quaternion()));
    }
    // LOD
    const dist = camera.position.distanceTo(this.shared.center);
    const rpx = (this.radius / (Math.max(dist, 1e-3) * Math.tan((camera.fov * DEG) / 2))) * (viewportHeightPx / 2);
    this.lastRadiusPx = rpx;
    this.setFar(rpx < 16);
    if (!this.farMode) {
      this.objects.faceCamera(camera.position);
      if (this.auto && !this.pendingTier) {
        const want = tierForScreenRadius(rpx, this.o.caps.maxTier);
        const next = nextTier(this.tier, want, rpx);
        if (next !== this.tier) {
          if (next > this.tier || nowMs - this.downgradeSince > 1500) { this.pendingTier = next; this.applyTier(next).finally(() => { this.pendingTier = null; }); }
          if (this.downgradeSince === 0) this.downgradeSince = nowMs;
        } else this.downgradeSince = nowMs;
      }
    }
  }
  get screenRadiusPx() { return this.lastRadiusPx; }
  get isFarMode() { return this.farMode; }

  private setFar(on: boolean) {
    if (on === this.farMode) return;
    this.farMode = on;
    const hide = [this.tilt, this.atmo, this.halo];
    hide.forEach((o) => { if (o) o.visible = !on; });
    if (on) {
      if (!this.far) {
        this.far = new THREE.Sprite(new THREE.SpriteMaterial({ transparent: true, depthWrite: false }));
        const k = 2 * this.radius / this.def.display.discFrac;
        this.far.scale.set(k, k, 1);
        this.root.add(this.far);
        const p = this.o.textures.acquire(this.o.url('thumbnail'), 'low', { aspect: 1, wrapS: THREE.ClampToEdgeWrapping });
        this.held.set('far', { key: p.key });
        p.then((t) => { (this.far!.material as THREE.SpriteMaterial).map = t; (this.far!.material as THREE.SpriteMaterial).needsUpdate = true; });
      }
      this.far.visible = true;
    } else if (this.far) this.far.visible = false;
  }

  /** NDC座標でのピック。物体 > 惑星表面 の順にデプスで判定(裏側の物体は惑星に遮られてヒットしない) */
  pick(ndc: THREE.Vector2, camera: THREE.Camera, ray?: THREE.Raycaster): PickResult | null {
    const rc = ray ?? new THREE.Raycaster();
    rc.setFromCamera(ndc, camera);
    const targets = [this.surface, ...this.objects.pickables()];
    const hits = rc.intersectObjects(targets, true);
    if (!hits.length) return null;
    const h = hits[0];
    const id = this.objects.idFromObject(h.object);
    if (id) return { kind: 'object', id, point: h.point };
    const local = this.spin.worldToLocal(h.point.clone());
    const ll = vecToLatLon(local.toArray() as [number, number, number]);
    return { kind: 'surface', lat: ll.lat, lon: ll.lon, point: h.point };
  }

  dispose() {
    this.disposed = true;
    this.held.forEach((k) => this.o.textures.release(k.key));
    this.held.clear();
    this.objects.dispose_all();
    this.root.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.material) (m.material as THREE.Material).dispose();
      if (m.geometry && m.geometry !== geoCache.get('')) { const g = m.geometry; if (!([...geoCache.values()] as THREE.BufferGeometry[]).includes(g)) g.dispose(); }
    });
    this.root.removeFromParent();
  }
}

function ringGeometry(inner: number, outer: number, seg = 192): THREE.BufferGeometry {
  const pos: number[] = [], uv: number[] = [], idx: number[] = [];
  for (let i = 0; i <= seg; i++) {
    const a = (i / seg) * Math.PI * 2, c = Math.cos(a), s = Math.sin(a);
    pos.push(c * inner, 0, -s * inner, c * outer, 0, -s * outer);
    uv.push(0, i / seg, 1, i / seg);
    if (i < seg) { const k = i * 2; idx.push(k, k + 1, k + 2, k + 1, k + 3, k + 2); }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  return g;
}
