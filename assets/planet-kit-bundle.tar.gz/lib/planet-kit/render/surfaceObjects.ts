import * as THREE from 'three';
import { surfaceFrame } from '../core/geo';
import { isOccludedBySphere } from '../core/visibility';
import { objFrag, objVert } from './shaders';

export type SurfaceKind = 'pin' | 'tower' | 'dome' | 'block' | 'billboard' | (string & {});
/**
 * 惑星表面に固定される配置物。建物(フェーズ4)・景観(フェーズ5)・地表施設はすべてこの仕様で配置する。
 * 位置は緯度・経度(度)。惑星の spin グループの子として置かれるため、自転に完全に追従する。
 */
export interface SurfaceObjectSpec {
  id: string;
  /** 描画方式。'billboard' は svgUrl の SVG を直立した板として描画する。それ以外は開発用プリミティブ。 */
  kind: SurfaceKind;
  /** 将来の建物ID(buildings.json)。描画方式の解決に使う */
  defId?: string;
  lat: number; lon: number;
  /** 惑星半径に対する底面サイズ(0.05 = 5%) */
  size: number;
  /** 惑星半径に対する高さ */
  height: number;
  /** 北から時計回りの度数 */
  heading: number;
  /** 表示レイヤー名。レイヤー単位で表示/非表示を切り替える */
  layer: string;
  /** false の間は「未解放」として半透明で表示(showLocked=false なら非表示) */
  unlocked: boolean;
  color?: string; glow?: string; label?: string; svgUrl?: string; data?: unknown;
}

interface Entry { spec: SurfaceObjectSpec; group: THREE.Group; inner: THREE.Group; materials: THREE.ShaderMaterial[]; selRing?: THREE.Mesh }
export interface SharedObjectUniforms { sun: THREE.Vector3; center: THREE.Vector3 }

export class SurfaceObjectManager {
  private entries = new Map<string, Entry>();
  private layers = new Map<string, boolean>();
  showLocked = true;
  private selectedId: string | null = null;
  constructor(private parent: THREE.Object3D, private radius: number, private shared: SharedObjectUniforms, private loadTexture?: (url: string) => Promise<THREE.Texture>) {}

  add(spec: SurfaceObjectSpec) {
    if (this.entries.has(spec.id)) throw new Error(`duplicate surface object id: ${spec.id}`);
    const group = new THREE.Group();
    const inner = new THREE.Group();
    group.add(inner);
    const entry: Entry = { spec, group, inner, materials: [] };
    this.build(entry);
    this.place(entry);
    this.parent.add(group);
    this.entries.set(spec.id, entry);
    this.applyState(entry);
  }
  update(id: string, patch: Partial<SurfaceObjectSpec>) {
    const e = this.must(id);
    const rebuild = ['kind', 'size', 'height', 'color', 'glow', 'svgUrl'].some((k) => k in patch);
    Object.assign(e.spec, patch);
    if (rebuild) { this.dispose(e, false); this.build(e); }
    this.place(e);
    this.applyState(e);
  }
  remove(id: string) {
    const e = this.entries.get(id); if (!e) return;
    this.dispose(e, true);
    this.entries.delete(id);
    if (this.selectedId === id) this.selectedId = null;
  }
  get(id: string): SurfaceObjectSpec | undefined { return this.entries.get(id)?.spec; }
  list(): SurfaceObjectSpec[] { return [...this.entries.values()].map((e) => e.spec); }
  setLayerVisible(layer: string, visible: boolean) { this.layers.set(layer, visible); this.entries.forEach((e) => this.applyState(e)); }
  setShowLocked(v: boolean) { this.showLocked = v; this.entries.forEach((e) => this.applyState(e)); }
  setSelected(id: string | null) {
    if (this.selectedId) { const o = this.entries.get(this.selectedId); if (o) this.styleSelected(o, false); }
    this.selectedId = id;
    if (id) { const o = this.entries.get(id); if (o) this.styleSelected(o, true); }
  }
  /** レイキャスト対象(可視のものだけ) */
  pickables(): THREE.Object3D[] { return [...this.entries.values()].filter((e) => e.group.visible).map((e) => e.inner); }
  idFromObject(o: THREE.Object3D | null): string | null {
    for (let c: THREE.Object3D | null = o; c; c = c.parent) if (c.userData.surfaceObjectId) return c.userData.surfaceObjectId as string;
    return null;
  }
  worldPosition(id: string, topFraction = 1): THREE.Vector3 {
    const e = this.must(id);
    const v = new THREE.Vector3(0, e.spec.height * this.radius * topFraction, 0);
    e.inner.updateWorldMatrix(true, false);
    return e.inner.localToWorld(v);
  }
  /** ラベル・HUD用: 表示状態(レイヤー/未解放設定)と惑星による隠蔽を考慮した可視判定 */
  isVisibleFrom(id: string, camera: THREE.Vector3): boolean {
    const e = this.must(id);
    if (!e.group.visible) return false;
    const p = this.worldPosition(id, 0.5);
    return !isOccludedBySphere(camera.toArray() as [number, number, number], p.toArray() as [number, number, number], this.shared.center.toArray() as [number, number, number], this.radius);
  }
  /** ビルボードを視点方向へ向ける(地表法線まわりの回転のみ) */
  faceCamera(camera: THREE.Vector3) {
    for (const e of this.entries.values()) {
      if (e.spec.kind !== 'billboard' || !e.group.visible) continue;
      const local = e.group.worldToLocal(camera.clone());
      e.inner.rotation.y = Math.atan2(local.x, local.z);
    }
  }
  dispose_all() { this.entries.forEach((e) => this.dispose(e, true)); this.entries.clear(); }

  private must(id: string): Entry { const e = this.entries.get(id); if (!e) throw new Error(`unknown surface object: ${id}`); return e; }
  private place(e: Entry) {
    const f = surfaceFrame(e.spec.lat, e.spec.lon);
    const east = new THREE.Vector3(...f.east), up = new THREE.Vector3(...f.up);
    const south = new THREE.Vector3().crossVectors(east, up);
    e.group.position.copy(up).multiplyScalar(this.radius * 0.999);
    e.group.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(east, up, south));
    if (e.spec.kind !== 'billboard') e.inner.rotation.y = -(e.spec.heading * Math.PI) / 180;
  }
  private applyState(e: Entry) {
    const layerOn = this.layers.get(e.spec.layer) ?? true;
    e.group.visible = layerOn && (e.spec.unlocked || this.showLocked);
    e.materials.forEach((m) => { m.uniforms.uGhost.value = e.spec.unlocked ? 0 : 1; m.transparent = !e.spec.unlocked; m.depthWrite = e.spec.unlocked; });
  }
  private styleSelected(e: Entry, on: boolean) {
    e.materials.forEach((m) => { m.uniforms.uSelected.value = on ? 1 : 0; });
    if (on && !e.selRing) {
      const r = e.spec.size * this.radius;
      const g = new THREE.RingGeometry(r * 0.75, r * 0.9, 40);
      g.rotateX(-Math.PI / 2);
      e.selRing = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: 0x66ddff, side: THREE.DoubleSide, transparent: true, opacity: 0.9, depthWrite: false }));
      e.selRing.position.y = r * 0.02;
      e.group.add(e.selRing);
    }
    if (e.selRing) e.selRing.visible = on;
  }
  private mat(e: Entry, color: string, glow: string): THREE.ShaderMaterial {
    const m = new THREE.ShaderMaterial({
      vertexShader: objVert, fragmentShader: objFrag, side: THREE.DoubleSide,
      uniforms: {
        uColor: { value: new THREE.Color(color) }, uGlow: { value: new THREE.Color(glow) },
        uSun: { value: this.shared.sun }, uCenter: { value: this.shared.center },
        uGhost: { value: 0 }, uSelected: { value: 0 }, uWinH: { value: 40 / Math.max(e.spec.height * this.radius, 1e-3) * 0.1 },
      },
    });
    e.materials.push(m);
    return m;
  }
  private build(e: Entry) {
    const { spec } = e;
    const s = spec.size * this.radius, h = spec.height * this.radius;
    const color = spec.color ?? '#c9d6e2', glow = spec.glow ?? '#ffcf7a';
    const add = (g: THREE.BufferGeometry, m: THREE.Material, y = 0) => { const mesh = new THREE.Mesh(g, m); mesh.position.y = y; mesh.userData.surfaceObjectId = spec.id; e.inner.add(mesh); return mesh; };
    e.inner.userData.surfaceObjectId = spec.id;
    switch (spec.kind) {
      case 'tower': add(new THREE.BoxGeometry(s * 0.5, h, s * 0.5), this.mat(e, color, glow), h / 2); add(new THREE.BoxGeometry(s * 0.28, h * 0.22, s * 0.28), this.mat(e, '#9fb3c6', glow), h * 1.11); break;
      case 'dome': add(new THREE.SphereGeometry(s * 0.5, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), this.mat(e, color, glow)); add(new THREE.CylinderGeometry(s * 0.52, s * 0.52, h * 0.12, 24), this.mat(e, '#7f93a6', glow), h * 0.06); break;
      case 'block': add(new THREE.BoxGeometry(s, h, s * 0.7), this.mat(e, color, glow), h / 2); break;
      case 'billboard': this.buildBillboard(e, s, h); break;
      default: { add(new THREE.ConeGeometry(s * 0.22, h, 12), this.mat(e, color, glow), h / 2); add(new THREE.SphereGeometry(s * 0.2, 14, 10), this.mat(e, '#ffffff', glow), h + s * 0.12); }
    }
  }
  private buildBillboard(e: Entry, s: number, h: number) {
    const geo = new THREE.PlaneGeometry(s, h); geo.translate(0, h / 2, 0);
    const mat = new THREE.MeshBasicMaterial({ transparent: true, side: THREE.DoubleSide, depthWrite: false, alphaTest: 0.02 });
    const mesh = new THREE.Mesh(geo, mat); mesh.userData.surfaceObjectId = e.spec.id; e.inner.add(mesh);
    if (e.spec.svgUrl && this.loadTexture) this.loadTexture(e.spec.svgUrl).then((t) => { mat.map = t; mat.needsUpdate = true; }).catch(() => { mat.color.set('#ff6677'); });
    else mat.color.set(e.spec.color ?? '#ffffff');
  }
  private dispose(e: Entry, removeGroup: boolean) {
    e.inner.traverse((o) => { const m = o as THREE.Mesh; if (m.geometry) m.geometry.dispose(); const mm = m.material as THREE.Material | undefined; if (mm) mm.dispose(); });
    e.inner.clear(); e.materials = [];
    if (removeGroup) { e.selRing?.geometry.dispose(); (e.selRing?.material as THREE.Material | undefined)?.dispose(); this.parent.remove(e.group); }
  }
}
