import type { MotionSpec, Vec3 } from './types';
import { orbitStateAt } from './orbit';
import { rotationAngle } from './time';

export interface BodyNode { id: string; parentId?: string; radius: number; motion: MotionSpec }
export interface BodyState { position: Vec3; rotation: number }

/**
 * 天体ツリー。惑星→衛星→人工衛星 のような入れ子の公転を、親の位置に子の軌道を足すだけで表現する。
 * 描画から独立した純粋な計算なので、将来の衛星・人工衛星・宇宙施設はノードを追加するだけでよい。
 */
export class SystemModel {
  private nodes = new Map<string, BodyNode>();
  constructor(public epochMs: number, nodes: BodyNode[] = []) { nodes.forEach((n) => this.add(n)); }
  add(n: BodyNode) {
    if (this.nodes.has(n.id)) throw new Error(`duplicate body id: ${n.id}`);
    if (n.parentId && !this.nodes.has(n.parentId)) throw new Error(`unknown parent: ${n.parentId}`);
    this.nodes.set(n.id, n);
  }
  remove(id: string) { this.nodes.delete(id); }
  get(id: string): BodyNode { const n = this.nodes.get(id); if (!n) throw new Error(`unknown body: ${id}`); return n; }
  children(id: string): BodyNode[] { return [...this.nodes.values()].filter((n) => n.parentId === id); }
  position(id: string, tMs: number): Vec3 {
    const n = this.get(id);
    const local: Vec3 = n.motion.orbit ? orbitStateAt(n.motion.orbit, this.epochMs, tMs).position : [0, 0, 0];
    if (!n.parentId) return local;
    const p = this.position(n.parentId, tMs);
    return [p[0] + local[0], p[1] + local[1], p[2] + local[2]];
  }
  state(id: string, tMs: number): BodyState {
    return { position: this.position(id, tMs), rotation: rotationAngle(this.get(id).motion, this.epochMs, tMs) };
  }
}
