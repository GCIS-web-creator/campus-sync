import type { OrbitSpec, Vec3 } from './types';
import { DEG, TAU, phaseCycles } from './time';

/** ケプラー方程式 M = E - e sin E をニュートン法で解く */
export function solveKepler(M: number, e: number): number {
  let m = ((M + Math.PI) % TAU + TAU) % TAU - Math.PI;
  let E = e < 0.8 ? m : Math.PI * Math.sign(m || 1);
  for (let i = 0; i < 30; i++) {
    const d = (E - e * Math.sin(E) - m) / (1 - e * Math.cos(E));
    E -= d;
    if (Math.abs(d) < 1e-12) break;
  }
  return E;
}

export interface OrbitState { position: Vec3; distance: number; trueAnomaly: number; meanAnomaly: number }

/**
 * 親天体を原点とした位置。基準面はXZ、軌道は +Y から見て反時計回り(順行)。
 * 変換: Ry(Ω) · Rx(i) · Ry(ω) · (軌道面内の位置)
 */
export function orbitStateAt(o: OrbitSpec, epochMs: number, tMs: number): OrbitState {
  const e = o.orbitalEccentricity;
  const a = o.orbitalRadius;
  const M = o.initialOrbitalPhaseDeg * DEG + phaseCycles(tMs - epochMs, o.orbitalPeriodSec) * TAU;
  const E = solveKepler(M, e);
  const xp = a * (Math.cos(E) - e);
  const zp = -a * Math.sqrt(1 - e * e) * Math.sin(E);
  const w = o.argumentOfPeriapsisDeg * DEG, inc = o.orbitalInclinationDeg * DEG, node = o.ascendingNodeDeg * DEG;
  // Ry(w)
  let x = xp * Math.cos(w) + zp * Math.sin(w);
  let y = 0;
  let z = -xp * Math.sin(w) + zp * Math.cos(w);
  // Rx(i)
  const y2 = y * Math.cos(inc) - z * Math.sin(inc);
  const z2 = y * Math.sin(inc) + z * Math.cos(inc);
  y = y2; z = z2;
  // Ry(node)
  const x3 = x * Math.cos(node) + z * Math.sin(node);
  const z3 = -x * Math.sin(node) + z * Math.cos(node);
  x = x3; z = z3;
  const nu = 2 * Math.atan2(Math.sqrt(1 + e) * Math.sin(E / 2), Math.sqrt(1 - e) * Math.cos(E / 2));
  return { position: [x, y, z], distance: Math.hypot(xp, zp), trueAnomaly: nu, meanAnomaly: M };
}

/** 軌道線の描画用サンプル(閉路) */
export function orbitPath(o: OrbitSpec, samples = 192): Vec3[] {
  const out: Vec3[] = [];
  for (let i = 0; i <= samples; i++) {
    const t = (i / samples) * o.orbitalPeriodSec * 1000;
    out.push(orbitStateAt(o, 0, t - (o.initialOrbitalPhaseDeg / 360) * o.orbitalPeriodSec * 1000).position);
  }
  return out;
}
