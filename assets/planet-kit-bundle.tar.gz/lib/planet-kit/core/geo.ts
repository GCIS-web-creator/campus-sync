import type { Vec3 } from './types';
import { DEG } from './time';

/**
 * 座標規約(表面テクスチャ・建物配置・生成ツールで共通):
 *   lon=0 → +X, lon=+90°(東) → -Z, lat=+90° → +Y。
 *   テクスチャ: u=(lon+180)/360, v=(lat+90)/180 (v=1 が北, three.js SphereGeometry の UV と一致)
 */
export function latLonToVec(latDeg: number, lonDeg: number, radius = 1): Vec3 {
  const la = latDeg * DEG, lo = lonDeg * DEG;
  const c = Math.cos(la);
  return [radius * c * Math.cos(lo), radius * Math.sin(la), -radius * c * Math.sin(lo)];
}
export function vecToLatLon(v: Vec3): { lat: number; lon: number } {
  const l = Math.hypot(v[0], v[1], v[2]) || 1;
  return { lat: Math.asin(Math.max(-1, Math.min(1, v[1] / l))) / DEG, lon: Math.atan2(-v[2], v[0]) / DEG };
}
export function latLonToUV(latDeg: number, lonDeg: number): { u: number; v: number } {
  return { u: (lonDeg + 180) / 360, v: (latDeg + 90) / 180 };
}
export function uvToLatLon(u: number, v: number): { lat: number; lon: number } {
  return { lat: v * 180 - 90, lon: u * 360 - 180 };
}
export interface SurfaceFrame { up: Vec3; east: Vec3; north: Vec3 }
/** 地表の局所座標系。east×up = south(= object の +Z) となる右手系を作る */
export function surfaceFrame(latDeg: number, lonDeg: number): SurfaceFrame {
  const la = latDeg * DEG, lo = lonDeg * DEG;
  const up = latLonToVec(latDeg, lonDeg, 1);
  const east: Vec3 = [-Math.sin(lo), 0, -Math.cos(lo)];
  const north: Vec3 = [-Math.sin(la) * Math.cos(lo), Math.cos(la), Math.sin(la) * Math.sin(lo)];
  return { up, east, north };
}
/** 大円距離(rad) */
export function angularDistance(a: { lat: number; lon: number }, b: { lat: number; lon: number }): number {
  const va = latLonToVec(a.lat, a.lon), vb = latLonToVec(b.lat, b.lon);
  return Math.acos(Math.max(-1, Math.min(1, va[0] * vb[0] + va[1] * vb[1] + va[2] * vb[2])));
}
