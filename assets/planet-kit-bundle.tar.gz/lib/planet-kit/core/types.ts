/** planets.json のスキーマ(campussync.planets/1)。単位: 角度=deg, 時間=秒, 距離=シーン単位(惑星半径が radius)。 */
export interface OrbitSpec {
  orbitalRadius: number;
  orbitalPeriodSec: number;
  orbitalEccentricity: number;
  orbitalInclinationDeg: number;
  ascendingNodeDeg: number;
  argumentOfPeriapsisDeg: number;
  /** epoch時点の平均近点角(deg) */
  initialOrbitalPhaseDeg: number;
}
export interface MotionSpec {
  /** 負値=逆行自転 */
  rotationPeriodSec: number;
  axialTiltDeg: number;
  /** 傾きの向き(Y軸まわり) */
  tiltAzimuthDeg: number;
  initialRotationDeg: number;
  orbit: OrbitSpec | null;
}
export interface AtmosphereSpec { color: string; thickness: number; intensity: number; falloff: number; halo: number }
export interface PlanetLayersSpec {
  relief: { strength: number };
  clouds: { opacity: number; rotationPeriodSec: number; altitude: number } | null;
  atmosphere: AtmosphereSpec | null;
  emissive: { intensity: number; dayFactor: number } | null;
  ring: { innerRadius: number; outerRadius: number; tiltDeg: number; rotationPeriodSec: number; opacity: number; litColor: string } | null;
}
export interface PlanetFiles { surface: string; preview: string; thumbnail: string; clouds?: string; emissive?: string; ring?: string }
export interface PlanetDef {
  id: string; name: string; nameEn: string; category: string; categoryLabel: string;
  description: string; tags: string[]; usage: string[];
  radius: number; palette: { primary: string; secondary: string; accent: string };
  /** preview/thumbnail.svg 内で惑星円が占める直径比 */
  display: { discFrac: number; previewView: { lon: number; lat: number; roll: number } };
  files: PlanetFiles; layers: PlanetLayersSpec; motion: MotionSpec;
}
export interface PlanetsFile { schema: string; epochMs: number; planets: PlanetDef[] }
export type CollectionStatus = { status: 'available'; index: string; count: number; ids: string[] } | { status: 'planned'; phase: number; target: number };
export interface Manifest { schema: string; version: string; basePath: string; collections: Record<string, CollectionStatus> }

export type Vec3 = [number, number, number];
