import type { MotionSpec } from './types';

export const TAU = Math.PI * 2;
export const DEG = Math.PI / 180;

/** dtMs 経過後の周期位相(-1..1)。周期が負なら負(逆行)。`%` は浮動小数でも厳密なので長時間経過後も精度が落ちない。 */
export function phaseCycles(dtMs: number, periodSec: number): number {
  const p = periodSec * 1000;
  return (dtMs % p) / p;
}
const wrap = (a: number) => ((a % TAU) + TAU) % TAU;

/** 絶対時刻 tMs における自転角(rad, 0..2π)。setInterval の積算ではなく「開始時刻からの経過」で計算する。 */
export function rotationAngle(m: Pick<MotionSpec, 'rotationPeriodSec' | 'initialRotationDeg'>, epochMs: number, tMs: number): number {
  return wrap(m.initialRotationDeg * DEG + phaseCycles(tMs - epochMs, m.rotationPeriodSec) * TAU);
}
export function cyclicAngle(initialDeg: number, periodSec: number, epochMs: number, tMs: number): number {
  return wrap(initialDeg * DEG + phaseCycles(tMs - epochMs, periodSec) * TAU);
}

export interface ClockState { simMs: number; wallMs: number; timeScale: number; paused: boolean }
/**
 * シミュレーション時計。表示用の時間 = 絶対時刻から計算される。
 * タブが非表示/ブラウザ停止の間も wall 時間は進むため、再表示時に正しい位置へ戻る。
 * (一時停止中は simMs が固定される)
 */
export class SimClock {
  private simAt: number;
  private wallAt: number;
  private scale: number;
  private _paused: boolean;
  constructor(init: Partial<ClockState> & { wallNow?: () => number } = {}) {
    this.wallNow = init.wallNow ?? (() => Date.now());
    this.wallAt = init.wallMs ?? this.wallNow();
    this.simAt = init.simMs ?? this.wallAt;
    this.scale = init.timeScale ?? 1;
    this._paused = init.paused ?? false;
  }
  private wallNow: () => number;
  now(wallMs = this.wallNow()): number {
    return this._paused ? this.simAt : this.simAt + (wallMs - this.wallAt) * this.scale;
  }
  get timeScale() { return this.scale; }
  get paused() { return this._paused; }
  private reanchor(wallMs = this.wallNow()) { this.simAt = this.now(wallMs); this.wallAt = wallMs; }
  setTimeScale(s: number) { this.reanchor(); this.scale = s; }
  pause() { if (this._paused) return; this.reanchor(); this._paused = true; }
  resume() { if (!this._paused) return; this._paused = false; this.wallAt = this.wallNow(); }
  seek(simMs: number) { this.simAt = simMs; this.wallAt = this.wallNow(); }
  /** 保存/復元用(localStorage等)。復元時は wall が進んでいるぶんだけ自動的に追従する。 */
  snapshot(): ClockState { return { simMs: this.simAt, wallMs: this.wallAt, timeScale: this.scale, paused: this._paused }; }
}
