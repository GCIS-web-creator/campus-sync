import type { Vec3 } from './types';

const sub = (a: Vec3, b: Vec3): Vec3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a: Vec3, b: Vec3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

/**
 * カメラから点への線分が球(惑星)に遮られるか。
 * 惑星の裏側にある建物・ラベルの非表示判定に使う(3D描画側はデプスバッファで自然に隠れる)。
 * 球半径をわずかに縮め、表面上の点自身は遮蔽扱いにならないようにしている。
 */
export function isOccludedBySphere(camera: Vec3, point: Vec3, center: Vec3, radius: number, shrink = 1e-3): boolean {
  const R = radius * (1 - shrink);
  const d = sub(point, camera);
  const f = sub(camera, center);
  const a = dot(d, d);
  const b = 2 * dot(f, d);
  const c = dot(f, f) - R * R;
  if (c < 0) return false; // カメラが球の内部
  const disc = b * b - 4 * a * c;
  if (disc <= 0) return false;
  const s = Math.sqrt(disc);
  const t1 = (-b - s) / (2 * a);
  return t1 > 0 && t1 < 1;
}
/** 表面法線 n(単位, ワールド) の地表点が、地平線の内側(=見える側)にあるか */
export function isOnNearSide(camera: Vec3, center: Vec3, radius: number, normal: Vec3): boolean {
  const toCam = sub(camera, center);
  const dist = Math.hypot(toCam[0], toCam[1], toCam[2]);
  if (dist <= radius) return true;
  return dot(normal, toCam) / dist > radius / dist;
}
