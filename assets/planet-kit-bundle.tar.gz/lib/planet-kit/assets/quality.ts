export type QualityTier = 'low' | 'medium' | 'high';
export const TIER_WIDTH: Record<QualityTier, number> = { low: 256, medium: 384, high: 512 };
const ORDER: QualityTier[] = ['low', 'medium', 'high'];

export interface DeviceCaps { maxTier: QualityTier; maxPixelRatio: number; sphereSegments: [number, number]; mobile: boolean }

/** 端末性能から上限を決める。WebGLの最大テクスチャサイズ(maxTextureSize)も考慮する。 */
export function detectCaps(opts: { maxTextureSize?: number; deviceMemory?: number; cores?: number; narrow?: boolean; dpr?: number } = {}): DeviceCaps {
  const nav = typeof navigator !== 'undefined' ? (navigator as Navigator & { deviceMemory?: number }) : undefined;
  const mem = opts.deviceMemory ?? nav?.deviceMemory ?? 8;
  const cores = opts.cores ?? nav?.hardwareConcurrency ?? 8;
  const narrow = opts.narrow ?? (typeof matchMedia !== 'undefined' ? matchMedia('(max-width: 820px)').matches : false);
  const mobile = narrow || mem <= 4;
  let maxTier: QualityTier = mobile ? 'medium' : 'high';
  if (mem <= 2 || cores <= 2) maxTier = 'low';
  const tex = opts.maxTextureSize ?? 8192;
  while (TIER_WIDTH[maxTier] > tex && maxTier !== 'low') maxTier = ORDER[ORDER.indexOf(maxTier) - 1];
  return { maxTier, maxPixelRatio: mobile ? 2 : 2.5, sphereSegments: mobile ? [64, 40] : [128, 80], mobile };
}
/** 画面上の惑星半径(デバイスpx)から必要なテクスチャ幅を決める。見える半球は幅の1/2なので、W >= 4*r で等倍以上になる */
export function tierForScreenRadius(radiusDevicePx: number, maxTier: QualityTier): QualityTier {
  const need = radiusDevicePx * 4;
  const t: QualityTier = need <= 256 ? 'low' : need <= 512 ? 'medium' : 'high';
  return ORDER[Math.min(ORDER.indexOf(t), ORDER.indexOf(maxTier))];
}
/** 切替のチャタリング防止: 上げるのは即時、下げるのは十分に余裕があるときだけ */
export function nextTier(current: QualityTier, wanted: QualityTier, radiusDevicePx: number): QualityTier {
  const ci = ORDER.indexOf(current), wi = ORDER.indexOf(wanted);
  if (wi > ci) return wanted;
  if (wi < ci && radiusDevicePx * 4 < TIER_WIDTH[current] * 0.45) return wanted;
  return current;
}
export const lowerTier = (t: QualityTier): QualityTier => ORDER[Math.max(0, ORDER.indexOf(t) - 1)];
