import type { Manifest, PlanetDef, PlanetFiles, PlanetsFile } from '../core/types';

export type PlanetFileRole = keyof PlanetFiles;

/**
 * manifest.json を起点に素材を引くカタログ。IDを渡すだけで定義とURLが得られる。
 * 将来のコレクション(moons, buildings ...)は collections に index が追加されるだけで同じ形で読める。
 */
export class AssetCatalog {
  private planetMap = new Map<string, PlanetDef>();
  private constructor(readonly base: string, readonly manifest: Manifest, readonly epochMs: number, planets: PlanetDef[]) {
    planets.forEach((p) => this.planetMap.set(p.id, p));
  }
  static async load(base = '/planet-assets', fetchFn: typeof fetch = fetch): Promise<AssetCatalog> {
    const b = base.replace(/\/$/, '');
    const m = await getJson<Manifest>(fetchFn, `${b}/manifest.json`);
    if (m.schema !== 'campussync.asset-manifest/1') throw new Error(`unsupported manifest schema: ${m.schema}`);
    const col = m.collections.planets;
    if (!col || col.status !== 'available') throw new Error('manifest has no available planets collection');
    const pf = await getJson<PlanetsFile>(fetchFn, `${b}/${col.index}`);
    if (pf.schema !== 'campussync.planets/1') throw new Error(`unsupported planets schema: ${pf.schema}`);
    return new AssetCatalog(b, m, pf.epochMs, pf.planets);
  }
  /** テストや組み込み用: 既に取得済みのJSONから構築 */
  static fromData(base: string, manifest: Manifest, planets: PlanetsFile): AssetCatalog {
    return new AssetCatalog(base.replace(/\/$/, ''), manifest, planets.epochMs, planets.planets);
  }
  planets(): PlanetDef[] { return [...this.planetMap.values()]; }
  hasPlanet(id: string) { return this.planetMap.has(id); }
  getPlanet(id: string): PlanetDef {
    const p = this.planetMap.get(id);
    if (!p) throw new Error(`unknown planet id: ${id}`);
    return p;
  }
  findPlanets(f: { category?: string; tag?: string }): PlanetDef[] {
    return this.planets().filter((p) => (!f.category || p.category === f.category) && (!f.tag || p.tags.includes(f.tag)));
  }
  /** 例: catalog.url('planet-001', 'thumbnail') */
  url(id: string, role: PlanetFileRole): string {
    const p = this.getPlanet(id);
    const rel = p.files[role];
    if (!rel) throw new Error(`${id} has no "${role}" file`);
    return `${this.base}/${rel}`;
  }
  hasFile(id: string, role: PlanetFileRole): boolean { return !!this.getPlanet(id).files[role]; }
}
async function getJson<T>(f: typeof fetch, url: string): Promise<T> {
  const r = await f(url);
  if (!r.ok) throw new Error(`failed to fetch ${url}: ${r.status}`);
  return (await r.json()) as T;
}
