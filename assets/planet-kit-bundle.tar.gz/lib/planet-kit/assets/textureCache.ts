import * as THREE from 'three';
import { TIER_WIDTH, type QualityTier } from './quality';

export interface RasterOpts { aspect?: number; wrapS?: THREE.Wrapping; wrapT?: THREE.Wrapping; srgb?: boolean }

/** 静的なJPEG/WebP素材をCanvasへ読み込みCanvasTexture化する。 */
export async function rasterizeSvg(url: string, width: number, aspect: number, fetchFn: typeof fetch = fetch): Promise<HTMLCanvasElement> {
  const res = await fetchFn(url);
  if (!res.ok) throw new Error(`failed to fetch ${url}: ${res.status}`);
  const blob = await res.blob();
  const blobUrl = URL.createObjectURL(blob.type ? blob : new Blob([blob], { type: url.endsWith('.webp') ? 'image/webp' : 'image/jpeg' }));
  try {
    const img = new Image();
    img.decoding = 'async';
    await new Promise<void>((ok, ng) => { img.onload = () => ok(); img.onerror = () => ng(new Error(`failed to decode planet texture: ${url}`)); img.src = blobUrl; });
    const c = document.createElement('canvas');
    c.width = width; c.height = Math.round(width * aspect);
    const ctx = c.getContext('2d')!;
    ctx.drawImage(img, 0, 0, c.width, c.height);
    return c;
  } finally { URL.revokeObjectURL(blobUrl); }
}

interface Entry { key: string; promise: Promise<THREE.Texture>; refs: number; texture?: THREE.Texture; bytes: number }

/**
 * (url, tier) 単位の参照カウント付きテクスチャキャッシュ。
 *  - 同じ画像の重複読み込み・重複ラスタライズを防ぐ(進行中のPromiseも共有)
 *  - 参照が0になったら dispose してGPU/CPUメモリを解放
 */
export class TextureCache {
  private map = new Map<string, Entry>();
  constructor(private maxAnisotropy = 4, private fetchFn: typeof fetch = fetch) {}
  setMaxAnisotropy(n: number) { this.maxAnisotropy = n; }
  acquire(url: string, tier: QualityTier, o: RasterOpts = {}): Promise<THREE.Texture> & { key: string } {
    const key = `${url}@${tier}`;
    let e = this.map.get(key);
    if (!e) {
      const width = TIER_WIDTH[tier] / (o.aspect === 0.25 ? 2 : 1);
      const entry: Entry = { key, refs: 0, bytes: 0, promise: undefined as unknown as Promise<THREE.Texture> };
      entry.promise = rasterizeSvg(url, width, o.aspect ?? 0.5, this.fetchFn).then((canvas) => {
        const t = new THREE.CanvasTexture(canvas);
        t.colorSpace = o.srgb === false ? THREE.NoColorSpace : THREE.SRGBColorSpace;
        t.wrapS = o.wrapS ?? THREE.RepeatWrapping;
        t.wrapT = o.wrapT ?? THREE.ClampToEdgeWrapping;
        t.anisotropy = this.maxAnisotropy;
        t.generateMipmaps = true;
        t.minFilter = THREE.LinearMipmapLinearFilter;
        entry.texture = t; entry.bytes = canvas.width * canvas.height * 4 * 1.33;
        if (entry.refs === 0) { t.dispose(); this.map.delete(key); }
        return t;
      });
      this.map.set(key, entry);
      e = entry;
    }
    e.refs++;
    return Object.assign(e.promise, { key });
  }
  release(key: string) {
    const e = this.map.get(key);
    if (!e) return;
    if (--e.refs <= 0) { e.texture?.dispose(); this.map.delete(key); }
  }
  stats() { let bytes = 0, n = 0; for (const e of this.map.values()) { if (e.texture) { bytes += e.bytes; n++; } } return { textures: n, estimatedBytes: bytes, entries: this.map.size }; }
  disposeAll() { for (const e of this.map.values()) e.texture?.dispose(); this.map.clear(); }
}
