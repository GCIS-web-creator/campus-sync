import { useEffect, useRef, useState } from 'react';
import { Vector2 } from 'three';
import type { AssetCatalog } from '../assets/catalog';
import type { QualityTier } from '../assets/quality';
import { loadPlanet } from '../render/loadPlanet';
import type { LayerName, PlanetView } from '../render/PlanetView';
import { Stage, type SunMode } from '../render/Stage';
import type { SurfaceObjectSpec } from '../render/surfaceObjects';
import { useAssetCatalog } from './useAssetCatalog';

export interface PlanetCanvasProps {
  /** 表示する惑星ID(planets.json の id) */
  planetId: string;
  catalog?: AssetCatalog;
  catalogBase?: string;
  quality?: QualityTier | 'auto';
  /** 1 = 実時間。0 で停止 */
  timeScale?: number;
  paused?: boolean;
  sun?: SunMode;
  layers?: Partial<Record<LayerName, boolean>>;
  /** 惑星表面に固定される配置物。id で差分更新される */
  objects?: SurfaceObjectSpec[];
  selectedObjectId?: string | null;
  /** 1 = 画面に収まる最小距離。大きいほど引く */
  cameraDistance?: number;
  onSelectObject?: (id: string | null) => void;
  onSurfaceTap?: (p: { lat: number; lon: number }) => void;
  onError?: (e: Error) => void;
  className?: string;
  style?: React.CSSProperties;
}

export function PlanetCanvas(props: PlanetCanvasProps) {
  const own = useAssetCatalog(props.catalog ? undefined : props.catalogBase);
  const catalog = props.catalog ?? own.catalog;
  const ref = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<Stage | null>(null);
  const viewRef = useRef<PlanetView | null>(null);
  const cb = useRef(props); cb.current = props;
  const [ready, setReady] = useState(0);

  useEffect(() => {
    if (own.error) props.onError?.(own.error);
  }, [own.error, props.onError]);

  useEffect(() => {
    if (!catalog || !ref.current) return;
    let stage: Stage;
    try {
      stage = new Stage({ canvas: ref.current }, catalog.epochMs);
    } catch (cause) {
      props.onError?.(cause instanceof Error ? cause : new Error('WebGL renderer could not be initialized.'));
      return;
    }
    stageRef.current = stage; stage.start();
    const c = ref.current;
    let down: { x: number; y: number; t: number } | null = null;
    const pd = (e: PointerEvent) => { down = { x: e.clientX, y: e.clientY, t: e.timeStamp }; };
    const pu = (e: PointerEvent) => {
      const v = viewRef.current; if (!down || !v) return;
      const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y), dt = e.timeStamp - down.t; down = null;
      if (moved > 6 || dt > 450) return;
      const r = c.getBoundingClientRect();
      const hit = v.pick(new Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -(((e.clientY - r.top) / r.height) * 2 - 1)), stage.camera);
      if (!hit) cb.current.onSelectObject?.(null);
      else if (hit.kind === 'object') cb.current.onSelectObject?.(hit.id);
      else cb.current.onSurfaceTap?.({ lat: hit.lat, lon: hit.lon });
    };
    c.addEventListener('pointerdown', pd); c.addEventListener('pointerup', pu);
    return () => { c.removeEventListener('pointerdown', pd); c.removeEventListener('pointerup', pu); stage.dispose(); stageRef.current = null; viewRef.current = null; };
  }, [catalog]);

  useEffect(() => {
    const stage = stageRef.current; if (!stage || !catalog) return;
    let cancelled = false;
    const prev = viewRef.current;
    loadPlanet(stage, catalog, props.planetId, props.quality ?? 'auto').then((v) => {
      if (cancelled) { stage.removePlanet(props.planetId); return; }
      if (prev && prev.def.id !== props.planetId) stage.removePlanet(prev.def.id);
      viewRef.current = v; stage.focus(props.planetId, props.cameraDistance ?? 1.1); setReady((n) => n + 1);
    }).catch((e: Error) => cb.current.onError?.(e));
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [catalog, props.planetId]);

  useEffect(() => { const s = stageRef.current; if (!s) return; s.clock.setTimeScale(props.timeScale ?? 1); }, [props.timeScale, ready]);
  useEffect(() => { const s = stageRef.current; if (!s) return; if (props.paused) s.clock.pause(); else if (props.paused === false) s.clock.resume(); }, [props.paused, ready]);
  useEffect(() => { if (stageRef.current && props.sun) stageRef.current.sun = props.sun; }, [props.sun, ready]);
  useEffect(() => { if (props.quality) viewRef.current?.setQuality(props.quality); }, [props.quality, ready]);
  useEffect(() => { const v = viewRef.current; if (!v || !props.layers) return; (Object.keys(props.layers) as LayerName[]).forEach((k) => v.setLayerVisible(k, !!props.layers![k])); }, [props.layers, ready]);
  useEffect(() => {
    const v = viewRef.current; if (!v) return;
    const want = new Map((props.objects ?? []).map((o) => [o.id, o]));
    for (const cur of v.objects.list()) if (!want.has(cur.id)) v.objects.remove(cur.id);
    for (const [id, spec] of want) { if (v.objects.get(id)) v.objects.update(id, spec); else v.objects.add({ ...spec }); }
  }, [props.objects, ready]);
  useEffect(() => { viewRef.current?.objects.setSelected(props.selectedObjectId ?? null); }, [props.selectedObjectId, ready, props.objects]);

  return <canvas ref={ref} className={props.className} style={{ width: '100%', height: '100%', display: 'block', touchAction: 'none', ...props.style }} />;
}
