import { useEffect, useState } from 'react';
import { AssetCatalog } from '../assets/catalog';

const cache = new Map<string, Promise<AssetCatalog>>();
/** manifest を1度だけ取得して共有する。IDを渡すだけで素材定義が引ける AssetCatalog を返す。 */
export function loadCatalogOnce(base: string): Promise<AssetCatalog> {
  let p = cache.get(base);
  if (!p) { p = AssetCatalog.load(base); p.catch(() => cache.delete(base)); cache.set(base, p); }
  return p;
}
export function useAssetCatalog(base = '/planet-assets'): { catalog: AssetCatalog | null; error: Error | null } {
  const [s, set] = useState<{ catalog: AssetCatalog | null; error: Error | null }>({ catalog: null, error: null });
  useEffect(() => {
    let live = true;
    loadCatalogOnce(base).then((c) => live && set({ catalog: c, error: null }), (e: Error) => live && set({ catalog: null, error: e }));
    return () => { live = false; };
  }, [base]);
  return s;
}
