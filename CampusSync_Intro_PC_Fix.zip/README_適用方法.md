# CampusSync イントロのPC表示修正

前回の変更でイントロ表示をPWAのみに制限していたため、PCの通常ブラウザーでは表示されなくなっていました。この修正では、そのPWA判定とsessionStorage判定をなくし、PCブラウザーとPWAの両方で、ページを開いた後の認証完了時にイントロを1回表示します。

画面内のタブ切替では `authUser` が変わらないため再表示しません。認証状態オブジェクトが更新された場合も、同じページの `useRef` に開始時刻を保持するため再生し直しません。ページを新しく開き直した場合は新しい起動として再生します。ユーザー端末で「視差効果を減らす／動きを減らす」が有効な場合は、従来どおりアニメーションを省略します。

## 適用方法

1. `campussync_intro_pc_fix.patch` をCodespacesのリポジトリ直下へアップロード。
2. ターミナルで適用可能かチェック：

   ```bash
   git apply --check campussync_intro_pc_fix.patch
   ```

3. チェックが成功したら適用し、ビルド：

   ```bash
   git apply campussync_intro_pc_fix.patch && git diff --check && npm run build
   ```

4. ビルド成功後、GitHubへ反映：

   ```bash
   git add app/page.tsx && git commit -m "Show intro on desktop browser launch" && git push origin main
   ```

`git apply --check` が失敗した場合は適用せず、今の `app/page.tsx` が前回のイントロ修正を含んでいるか確認してください。
