CampusSync 課題・提出期限管理の導入

このセットは、Admin／先生が共有課題と正確な期限を登録し、学生側の「マイ提出物・連絡リマインダー」へ表示するための変更です。既存の個人用 todos は残します。Admin共通課題の期限は学生側から変更できません。

ファイル
- page-assignments.tsx: 学生側ページの修正版。プロジェクトの現在の app/page.tsx と置き換えます。
- Admin-assignments.tsx: 送ってもらった Admin(3).tsx に課題管理タブを追加した版。プロジェクト内の既存Adminコンポーネントのファイルと置き換えてください（元の配置パスはこのファイルだけでは確定できないため、現在のAdminファイルと同じ場所に保存します）。
- route.ts: app/api/admin/assignments/route.ts に保存してください。
- assignments.sql: Supabase SQL Editor で実行してください。

必須設定
1. Supabase Dashboard > SQL Editor で assignments.sql を実行。
2. VercelのProject Settings > Environment Variablesに次を設定（Production/Preview/Developmentで必要な環境を選択）。
   - SUPABASE_SERVICE_ROLE_KEY: Supabaseのサーバー専用Secret/service_role key。絶対に NEXT_PUBLIC_ を付けない。学生側コードへ書かない。チャットにも貼らない。
   - CAMPUS_SYNC_ADMIN_PASSWORD: 自分で決めた長く推測されにくい管理用パスワード。
   - NEXT_PUBLIC_SUPABASE_URL: 既に設定済みのSupabase URL。
3. 必ず再デプロイ。
4. Admin画面の「課題・提出期限管理」タブで CAMPUS_SYNC_ADMIN_PASSWORD と同じパスワードを入力し「課題一覧を読み込む」を押す。
5. 課題名・詳細・日付時刻を入力して「学生全員に課題を公開」を押す。

注意
- SUPABASE_SERVICE_ROLE_KEYは管理APIサーバー専用です。NEXT_PUBLIC_で公開したり、page.tsx/Adminファイルに直接書いたりしないでください。
- Adminコンポーネントの実際の保存場所はアップロード時のファイル名だけではわからないため、既存ファイルを見つけて置き換えてください。
- まだGoogle Classroom APIとのOAuth連携は有効化していません。このデータベースにはClassroomのcourse ID / coursework IDを保存できる欄を用意しています。Google Cloud側のAPI有効化、OAuth同意画面と権限、学校のGoogle Workspace管理者による許可が必要なため、Admin課題管理を先に動かしてから次段階として接続します。
- 動作確認はこの作業環境にSupabaseとVercelの秘密設定がないため、実環境に接続した統合テストまでは行っていません。
