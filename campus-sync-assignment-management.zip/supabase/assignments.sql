-- CampusSync 共通課題・学生ごとの完了状態
-- Supabase Dashboard > SQL Editor で全体を実行してください。

create extension if not exists pgcrypto;

create table if not exists public.assignments (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  details text not null default '',
  source text not null default 'Admin／先生',
  type text not null default 'paper' check (type in ('paper', 'classroom', 'other')),
  due text not null default '期限未設定',
  due_at timestamptz null,
  is_active boolean not null default true,
  classroom_course_id text null,
  classroom_coursework_id text null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (classroom_course_id, classroom_coursework_id)
);

create index if not exists assignments_active_created_at_idx
  on public.assignments (is_active, created_at desc);

create table if not exists public.assignment_completions (
  id uuid primary key default gen_random_uuid(),
  student_id text not null check (student_id ~ '^[0-9]{6}$'),
  assignment_id uuid not null references public.assignments(id) on delete cascade,
  completed boolean not null default false,
  updated_at timestamptz not null default now(),
  unique (student_id, assignment_id)
);

alter table public.assignments enable row level security;
alter table public.assignment_completions enable row level security;

-- 課題の内容は表示用として読めるが、作成・変更・削除はサーバー側の管理APIだけが行う。
drop policy if exists "active assignments are readable" on public.assignments;
create policy "active assignments are readable"
  on public.assignments for select to authenticated
  using (is_active = true);
grant select on public.assignments to authenticated;

-- 完了状態は、認証メールの@前の6桁が一致する本人の行だけ操作できる。
-- 学校メールのドメイン制限も合わせて検証する。
drop policy if exists "students read own assignment completions" on public.assignment_completions;
create policy "students read own assignment completions"
  on public.assignment_completions for select to authenticated
  using (
    student_id = split_part(coalesce(auth.jwt()->>'email', ''), '@', 1)
    and coalesce(auth.jwt()->>'email', '') ~* '^[0-9]{6}@tokyo\.soka\.ed\.jp$'
  );

drop policy if exists "students insert own assignment completions" on public.assignment_completions;
create policy "students insert own assignment completions"
  on public.assignment_completions for insert to authenticated
  with check (
    student_id = split_part(coalesce(auth.jwt()->>'email', ''), '@', 1)
    and coalesce(auth.jwt()->>'email', '') ~* '^[0-9]{6}@tokyo\.soka\.ed\.jp$'
  );

drop policy if exists "students update own assignment completions" on public.assignment_completions;
create policy "students update own assignment completions"
  on public.assignment_completions for update to authenticated
  using (
    student_id = split_part(coalesce(auth.jwt()->>'email', ''), '@', 1)
    and coalesce(auth.jwt()->>'email', '') ~* '^[0-9]{6}@tokyo\.soka\.ed\.jp$'
  )
  with check (
    student_id = split_part(coalesce(auth.jwt()->>'email', ''), '@', 1)
    and coalesce(auth.jwt()->>'email', '') ~* '^[0-9]{6}@tokyo\.soka\.ed\.jp$'
  );

grant select, insert, update on public.assignment_completions to authenticated;
